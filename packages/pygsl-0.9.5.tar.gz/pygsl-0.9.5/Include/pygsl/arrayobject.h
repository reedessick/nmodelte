/*
	       WARNING: File Generated during build. DO NOT MODIFY!!!
	*/
#define PyGSL_NUMPY 1
