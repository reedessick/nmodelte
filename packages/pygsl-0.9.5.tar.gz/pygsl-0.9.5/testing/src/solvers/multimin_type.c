/*
 * author:  Pierre Schnizer
 * created: December 2003
 * file: pygsl/src/multimin_type.c
 * $Id: multimin_type.c,v 1.1 2005/07/21 09:25:50 schnizer Exp $
 */

/* Generic type. Covers multimin and multimin_fdf */

/*
 * Local Variables:
 * mode: C
 * c-file-style: "python"
 * End:
 */
