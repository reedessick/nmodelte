/*Using complex_polar as pyton name*/
static void * complex_polar_data [] = { (void *) gsl_complex_polar, (void *) gsl_complex_polar };

/*Using complex_rect as pyton name*/
static void * complex_rect_data [] = { (void *) gsl_complex_rect, (void *) gsl_complex_rect };

/*Using complex_abs as pyton name*/
static void * complex_abs_data [] = { (void *) gsl_complex_abs, (void *) gsl_complex_abs };

/*Using complex_abs2 as pyton name*/
static void * complex_abs2_data [] = { (void *) gsl_complex_abs2, (void *) gsl_complex_abs2 };

/*Using complex_logabs as pyton name*/
static void * complex_logabs_data [] = { (void *) gsl_complex_logabs, (void *) gsl_complex_logabs };

/*Using complex_add as pyton name*/
static void * complex_add_data [] = { (void *) gsl_complex_add, (void *) gsl_complex_add };

/*Using complex_sub as pyton name*/
static void * complex_sub_data [] = { (void *) gsl_complex_sub, (void *) gsl_complex_sub };

/*Using complex_mul as pyton name*/
static void * complex_mul_data [] = { (void *) gsl_complex_mul, (void *) gsl_complex_mul };

/*Using complex_div as pyton name*/
static void * complex_div_data [] = { (void *) gsl_complex_div, (void *) gsl_complex_div };

/*Using complex_add_real as pyton name*/
static void * complex_add_real_data [] = { (void *) gsl_complex_add_real, (void *) gsl_complex_add_real };

/*Using complex_sub_real as pyton name*/
static void * complex_sub_real_data [] = { (void *) gsl_complex_sub_real, (void *) gsl_complex_sub_real };

/*Using complex_mul_real as pyton name*/
static void * complex_mul_real_data [] = { (void *) gsl_complex_mul_real, (void *) gsl_complex_mul_real };

/*Using complex_div_real as pyton name*/
static void * complex_div_real_data [] = { (void *) gsl_complex_div_real, (void *) gsl_complex_div_real };

/*Using complex_add_imag as pyton name*/
static void * complex_add_imag_data [] = { (void *) gsl_complex_add_imag, (void *) gsl_complex_add_imag };

/*Using complex_sub_imag as pyton name*/
static void * complex_sub_imag_data [] = { (void *) gsl_complex_sub_imag, (void *) gsl_complex_sub_imag };

/*Using complex_mul_imag as pyton name*/
static void * complex_mul_imag_data [] = { (void *) gsl_complex_mul_imag, (void *) gsl_complex_mul_imag };

/*Using complex_div_imag as pyton name*/
static void * complex_div_imag_data [] = { (void *) gsl_complex_div_imag, (void *) gsl_complex_div_imag };

/*Using complex_conjugate as pyton name*/
static void * complex_conjugate_data [] = { (void *) gsl_complex_conjugate, (void *) gsl_complex_conjugate };

/*Using complex_inverse as pyton name*/
static void * complex_inverse_data [] = { (void *) gsl_complex_inverse, (void *) gsl_complex_inverse };

/*Using complex_negative as pyton name*/
static void * complex_negative_data [] = { (void *) gsl_complex_negative, (void *) gsl_complex_negative };

/*Using complex_sqrt as pyton name*/
static void * complex_sqrt_data [] = { (void *) gsl_complex_sqrt, (void *) gsl_complex_sqrt };

/*Using complex_sqrt_real as pyton name*/
static void * complex_sqrt_real_data [] = { (void *) gsl_complex_sqrt_real, (void *) gsl_complex_sqrt_real };

/*Using complex_pow as pyton name*/
static void * complex_pow_data [] = { (void *) gsl_complex_pow, (void *) gsl_complex_pow };

/*Using complex_pow_real as pyton name*/
static void * complex_pow_real_data [] = { (void *) gsl_complex_pow_real, (void *) gsl_complex_pow_real };

/*Using complex_exp as pyton name*/
static void * complex_exp_data [] = { (void *) gsl_complex_exp, (void *) gsl_complex_exp };

/*Using complex_log as pyton name*/
static void * complex_log_data [] = { (void *) gsl_complex_log, (void *) gsl_complex_log };

/*Using complex_log10 as pyton name*/
static void * complex_log10_data [] = { (void *) gsl_complex_log10, (void *) gsl_complex_log10 };

/*Using complex_log_b as pyton name*/
static void * complex_log_b_data [] = { (void *) gsl_complex_log_b, (void *) gsl_complex_log_b };

/*Using complex_sin as pyton name*/
static void * complex_sin_data [] = { (void *) gsl_complex_sin, (void *) gsl_complex_sin };

/*Using complex_cos as pyton name*/
static void * complex_cos_data [] = { (void *) gsl_complex_cos, (void *) gsl_complex_cos };

/*Using complex_sec as pyton name*/
static void * complex_sec_data [] = { (void *) gsl_complex_sec, (void *) gsl_complex_sec };

/*Using complex_csc as pyton name*/
static void * complex_csc_data [] = { (void *) gsl_complex_csc, (void *) gsl_complex_csc };

/*Using complex_tan as pyton name*/
static void * complex_tan_data [] = { (void *) gsl_complex_tan, (void *) gsl_complex_tan };

/*Using complex_cot as pyton name*/
static void * complex_cot_data [] = { (void *) gsl_complex_cot, (void *) gsl_complex_cot };

/*Using complex_arcsin as pyton name*/
static void * complex_arcsin_data [] = { (void *) gsl_complex_arcsin, (void *) gsl_complex_arcsin };

/*Using complex_arcsin_real as pyton name*/
static void * complex_arcsin_real_data [] = { (void *) gsl_complex_arcsin_real, (void *) gsl_complex_arcsin_real };

/*Using complex_arccos as pyton name*/
static void * complex_arccos_data [] = { (void *) gsl_complex_arccos, (void *) gsl_complex_arccos };

/*Using complex_arccos_real as pyton name*/
static void * complex_arccos_real_data [] = { (void *) gsl_complex_arccos_real, (void *) gsl_complex_arccos_real };

/*Using complex_arcsec as pyton name*/
static void * complex_arcsec_data [] = { (void *) gsl_complex_arcsec, (void *) gsl_complex_arcsec };

/*Using complex_arcsec_real as pyton name*/
static void * complex_arcsec_real_data [] = { (void *) gsl_complex_arcsec_real, (void *) gsl_complex_arcsec_real };

/*Using complex_arccsc as pyton name*/
static void * complex_arccsc_data [] = { (void *) gsl_complex_arccsc, (void *) gsl_complex_arccsc };

/*Using complex_arccsc_real as pyton name*/
static void * complex_arccsc_real_data [] = { (void *) gsl_complex_arccsc_real, (void *) gsl_complex_arccsc_real };

/*Using complex_arctan as pyton name*/
static void * complex_arctan_data [] = { (void *) gsl_complex_arctan, (void *) gsl_complex_arctan };

/*Using complex_arccot as pyton name*/
static void * complex_arccot_data [] = { (void *) gsl_complex_arccot, (void *) gsl_complex_arccot };

/*Using complex_sinh as pyton name*/
static void * complex_sinh_data [] = { (void *) gsl_complex_sinh, (void *) gsl_complex_sinh };

/*Using complex_cosh as pyton name*/
static void * complex_cosh_data [] = { (void *) gsl_complex_cosh, (void *) gsl_complex_cosh };

/*Using complex_sech as pyton name*/
static void * complex_sech_data [] = { (void *) gsl_complex_sech, (void *) gsl_complex_sech };

/*Using complex_csch as pyton name*/
static void * complex_csch_data [] = { (void *) gsl_complex_csch, (void *) gsl_complex_csch };

/*Using complex_tanh as pyton name*/
static void * complex_tanh_data [] = { (void *) gsl_complex_tanh, (void *) gsl_complex_tanh };

/*Using complex_coth as pyton name*/
static void * complex_coth_data [] = { (void *) gsl_complex_coth, (void *) gsl_complex_coth };

/*Using complex_arcsinh as pyton name*/
static void * complex_arcsinh_data [] = { (void *) gsl_complex_arcsinh, (void *) gsl_complex_arcsinh };

/*Using complex_arccosh as pyton name*/
static void * complex_arccosh_data [] = { (void *) gsl_complex_arccosh, (void *) gsl_complex_arccosh };

/*Using complex_arccosh_real as pyton name*/
static void * complex_arccosh_real_data [] = { (void *) gsl_complex_arccosh_real, (void *) gsl_complex_arccosh_real };

/*Using complex_arcsech as pyton name*/
static void * complex_arcsech_data [] = { (void *) gsl_complex_arcsech, (void *) gsl_complex_arcsech };

/*Using complex_arccsch as pyton name*/
static void * complex_arccsch_data [] = { (void *) gsl_complex_arccsch, (void *) gsl_complex_arccsch };

/*Using complex_arctanh as pyton name*/
static void * complex_arctanh_data [] = { (void *) gsl_complex_arctanh, (void *) gsl_complex_arctanh };

/*Using complex_arctanh_real as pyton name*/
static void * complex_arctanh_real_data [] = { (void *) gsl_complex_arctanh_real, (void *) gsl_complex_arctanh_real };

/*Using complex_arccoth as pyton name*/
static void * complex_arccoth_data [] = { (void *) gsl_complex_arccoth, (void *) gsl_complex_arccoth };

/*Using sf_airy_Ai_e as pyton name*/
static void * sf_airy_Ai_e_data [] = { (void *) gsl_sf_airy_Ai_e, (void *) gsl_sf_airy_Ai_e };

/*Using sf_airy_Ai as pyton name*/
static void * sf_airy_Ai_data [] = { (void *) gsl_sf_airy_Ai, (void *) gsl_sf_airy_Ai };

/*Using sf_airy_Bi_e as pyton name*/
static void * sf_airy_Bi_e_data [] = { (void *) gsl_sf_airy_Bi_e, (void *) gsl_sf_airy_Bi_e };

/*Using sf_airy_Bi as pyton name*/
static void * sf_airy_Bi_data [] = { (void *) gsl_sf_airy_Bi, (void *) gsl_sf_airy_Bi };

/*Using sf_airy_Ai_scaled_e as pyton name*/
static void * sf_airy_Ai_scaled_e_data [] = { (void *) gsl_sf_airy_Ai_scaled_e, (void *) gsl_sf_airy_Ai_scaled_e };

/*Using sf_airy_Ai_scaled as pyton name*/
static void * sf_airy_Ai_scaled_data [] = { (void *) gsl_sf_airy_Ai_scaled, (void *) gsl_sf_airy_Ai_scaled };

/*Using sf_airy_Bi_scaled_e as pyton name*/
static void * sf_airy_Bi_scaled_e_data [] = { (void *) gsl_sf_airy_Bi_scaled_e, (void *) gsl_sf_airy_Bi_scaled_e };

/*Using sf_airy_Bi_scaled as pyton name*/
static void * sf_airy_Bi_scaled_data [] = { (void *) gsl_sf_airy_Bi_scaled, (void *) gsl_sf_airy_Bi_scaled };

/*Using sf_airy_Ai_deriv_e as pyton name*/
static void * sf_airy_Ai_deriv_e_data [] = { (void *) gsl_sf_airy_Ai_deriv_e, (void *) gsl_sf_airy_Ai_deriv_e };

/*Using sf_airy_Ai_deriv as pyton name*/
static void * sf_airy_Ai_deriv_data [] = { (void *) gsl_sf_airy_Ai_deriv, (void *) gsl_sf_airy_Ai_deriv };

/*Using sf_airy_Bi_deriv_e as pyton name*/
static void * sf_airy_Bi_deriv_e_data [] = { (void *) gsl_sf_airy_Bi_deriv_e, (void *) gsl_sf_airy_Bi_deriv_e };

/*Using sf_airy_Bi_deriv as pyton name*/
static void * sf_airy_Bi_deriv_data [] = { (void *) gsl_sf_airy_Bi_deriv, (void *) gsl_sf_airy_Bi_deriv };

/*Using sf_airy_Ai_deriv_scaled_e as pyton name*/
static void * sf_airy_Ai_deriv_scaled_e_data [] = { (void *) gsl_sf_airy_Ai_deriv_scaled_e, (void *) gsl_sf_airy_Ai_deriv_scaled_e };

/*Using sf_airy_Ai_deriv_scaled as pyton name*/
static void * sf_airy_Ai_deriv_scaled_data [] = { (void *) gsl_sf_airy_Ai_deriv_scaled, (void *) gsl_sf_airy_Ai_deriv_scaled };

/*Using sf_airy_Bi_deriv_scaled_e as pyton name*/
static void * sf_airy_Bi_deriv_scaled_e_data [] = { (void *) gsl_sf_airy_Bi_deriv_scaled_e, (void *) gsl_sf_airy_Bi_deriv_scaled_e };

/*Using sf_airy_Bi_deriv_scaled as pyton name*/
static void * sf_airy_Bi_deriv_scaled_data [] = { (void *) gsl_sf_airy_Bi_deriv_scaled, (void *) gsl_sf_airy_Bi_deriv_scaled };

/*Using sf_airy_zero_Ai_e as pyton name*/
static void * sf_airy_zero_Ai_e_data [] = { (void *) gsl_sf_airy_zero_Ai_e, (void *) gsl_sf_airy_zero_Ai_e };

/*Using sf_airy_zero_Ai as pyton name*/
static void * sf_airy_zero_Ai_data [] = { (void *) gsl_sf_airy_zero_Ai, (void *) gsl_sf_airy_zero_Ai };

/*Using sf_airy_zero_Bi_e as pyton name*/
static void * sf_airy_zero_Bi_e_data [] = { (void *) gsl_sf_airy_zero_Bi_e, (void *) gsl_sf_airy_zero_Bi_e };

/*Using sf_airy_zero_Bi as pyton name*/
static void * sf_airy_zero_Bi_data [] = { (void *) gsl_sf_airy_zero_Bi, (void *) gsl_sf_airy_zero_Bi };

/*Using sf_airy_zero_Ai_deriv_e as pyton name*/
static void * sf_airy_zero_Ai_deriv_e_data [] = { (void *) gsl_sf_airy_zero_Ai_deriv_e, (void *) gsl_sf_airy_zero_Ai_deriv_e };

/*Using sf_airy_zero_Ai_deriv as pyton name*/
static void * sf_airy_zero_Ai_deriv_data [] = { (void *) gsl_sf_airy_zero_Ai_deriv, (void *) gsl_sf_airy_zero_Ai_deriv };

/*Using sf_airy_zero_Bi_deriv_e as pyton name*/
static void * sf_airy_zero_Bi_deriv_e_data [] = { (void *) gsl_sf_airy_zero_Bi_deriv_e, (void *) gsl_sf_airy_zero_Bi_deriv_e };

/*Using sf_airy_zero_Bi_deriv as pyton name*/
static void * sf_airy_zero_Bi_deriv_data [] = { (void *) gsl_sf_airy_zero_Bi_deriv, (void *) gsl_sf_airy_zero_Bi_deriv };

/*Using sf_bessel_J0_e as pyton name*/
static void * sf_bessel_J0_e_data [] = { (void *) gsl_sf_bessel_J0_e, (void *) gsl_sf_bessel_J0_e };

/*Using sf_bessel_J0 as pyton name*/
static void * sf_bessel_J0_data [] = { (void *) gsl_sf_bessel_J0, (void *) gsl_sf_bessel_J0 };

/*Using sf_bessel_J1_e as pyton name*/
static void * sf_bessel_J1_e_data [] = { (void *) gsl_sf_bessel_J1_e, (void *) gsl_sf_bessel_J1_e };

/*Using sf_bessel_J1 as pyton name*/
static void * sf_bessel_J1_data [] = { (void *) gsl_sf_bessel_J1, (void *) gsl_sf_bessel_J1 };

/*Using sf_bessel_Jn_e as pyton name*/
static void * sf_bessel_Jn_e_data [] = { (void *) gsl_sf_bessel_Jn_e, (void *) gsl_sf_bessel_Jn_e };

/*Using sf_bessel_Jn as pyton name*/
static void * sf_bessel_Jn_data [] = { (void *) gsl_sf_bessel_Jn, (void *) gsl_sf_bessel_Jn };

/*Using sf_bessel_Y0_e as pyton name*/
static void * sf_bessel_Y0_e_data [] = { (void *) gsl_sf_bessel_Y0_e, (void *) gsl_sf_bessel_Y0_e };

/*Using sf_bessel_Y0 as pyton name*/
static void * sf_bessel_Y0_data [] = { (void *) gsl_sf_bessel_Y0, (void *) gsl_sf_bessel_Y0 };

/*Using sf_bessel_Y1_e as pyton name*/
static void * sf_bessel_Y1_e_data [] = { (void *) gsl_sf_bessel_Y1_e, (void *) gsl_sf_bessel_Y1_e };

/*Using sf_bessel_Y1 as pyton name*/
static void * sf_bessel_Y1_data [] = { (void *) gsl_sf_bessel_Y1, (void *) gsl_sf_bessel_Y1 };

/*Using sf_bessel_Yn_e as pyton name*/
static void * sf_bessel_Yn_e_data [] = { (void *) gsl_sf_bessel_Yn_e, (void *) gsl_sf_bessel_Yn_e };

/*Using sf_bessel_Yn as pyton name*/
static void * sf_bessel_Yn_data [] = { (void *) gsl_sf_bessel_Yn, (void *) gsl_sf_bessel_Yn };

/*Using sf_bessel_I0_e as pyton name*/
static void * sf_bessel_I0_e_data [] = { (void *) gsl_sf_bessel_I0_e, (void *) gsl_sf_bessel_I0_e };

/*Using sf_bessel_I0 as pyton name*/
static void * sf_bessel_I0_data [] = { (void *) gsl_sf_bessel_I0, (void *) gsl_sf_bessel_I0 };

/*Using sf_bessel_I1_e as pyton name*/
static void * sf_bessel_I1_e_data [] = { (void *) gsl_sf_bessel_I1_e, (void *) gsl_sf_bessel_I1_e };

/*Using sf_bessel_I1 as pyton name*/
static void * sf_bessel_I1_data [] = { (void *) gsl_sf_bessel_I1, (void *) gsl_sf_bessel_I1 };

/*Using sf_bessel_In_e as pyton name*/
static void * sf_bessel_In_e_data [] = { (void *) gsl_sf_bessel_In_e, (void *) gsl_sf_bessel_In_e };

/*Using sf_bessel_In as pyton name*/
static void * sf_bessel_In_data [] = { (void *) gsl_sf_bessel_In, (void *) gsl_sf_bessel_In };

/*Using sf_bessel_I0_scaled_e as pyton name*/
static void * sf_bessel_I0_scaled_e_data [] = { (void *) gsl_sf_bessel_I0_scaled_e, (void *) gsl_sf_bessel_I0_scaled_e };

/*Using sf_bessel_I0_scaled as pyton name*/
static void * sf_bessel_I0_scaled_data [] = { (void *) gsl_sf_bessel_I0_scaled, (void *) gsl_sf_bessel_I0_scaled };

/*Using sf_bessel_I1_scaled_e as pyton name*/
static void * sf_bessel_I1_scaled_e_data [] = { (void *) gsl_sf_bessel_I1_scaled_e, (void *) gsl_sf_bessel_I1_scaled_e };

/*Using sf_bessel_I1_scaled as pyton name*/
static void * sf_bessel_I1_scaled_data [] = { (void *) gsl_sf_bessel_I1_scaled, (void *) gsl_sf_bessel_I1_scaled };

/*Using sf_bessel_In_scaled_e as pyton name*/
static void * sf_bessel_In_scaled_e_data [] = { (void *) gsl_sf_bessel_In_scaled_e, (void *) gsl_sf_bessel_In_scaled_e };

/*Using sf_bessel_In_scaled as pyton name*/
static void * sf_bessel_In_scaled_data [] = { (void *) gsl_sf_bessel_In_scaled, (void *) gsl_sf_bessel_In_scaled };

/*Using sf_bessel_K0_e as pyton name*/
static void * sf_bessel_K0_e_data [] = { (void *) gsl_sf_bessel_K0_e, (void *) gsl_sf_bessel_K0_e };

/*Using sf_bessel_K0 as pyton name*/
static void * sf_bessel_K0_data [] = { (void *) gsl_sf_bessel_K0, (void *) gsl_sf_bessel_K0 };

/*Using sf_bessel_K1_e as pyton name*/
static void * sf_bessel_K1_e_data [] = { (void *) gsl_sf_bessel_K1_e, (void *) gsl_sf_bessel_K1_e };

/*Using sf_bessel_K1 as pyton name*/
static void * sf_bessel_K1_data [] = { (void *) gsl_sf_bessel_K1, (void *) gsl_sf_bessel_K1 };

/*Using sf_bessel_Kn_e as pyton name*/
static void * sf_bessel_Kn_e_data [] = { (void *) gsl_sf_bessel_Kn_e, (void *) gsl_sf_bessel_Kn_e };

/*Using sf_bessel_Kn as pyton name*/
static void * sf_bessel_Kn_data [] = { (void *) gsl_sf_bessel_Kn, (void *) gsl_sf_bessel_Kn };

/*Using sf_bessel_K0_scaled_e as pyton name*/
static void * sf_bessel_K0_scaled_e_data [] = { (void *) gsl_sf_bessel_K0_scaled_e, (void *) gsl_sf_bessel_K0_scaled_e };

/*Using sf_bessel_K0_scaled as pyton name*/
static void * sf_bessel_K0_scaled_data [] = { (void *) gsl_sf_bessel_K0_scaled, (void *) gsl_sf_bessel_K0_scaled };

/*Using sf_bessel_K1_scaled_e as pyton name*/
static void * sf_bessel_K1_scaled_e_data [] = { (void *) gsl_sf_bessel_K1_scaled_e, (void *) gsl_sf_bessel_K1_scaled_e };

/*Using sf_bessel_K1_scaled as pyton name*/
static void * sf_bessel_K1_scaled_data [] = { (void *) gsl_sf_bessel_K1_scaled, (void *) gsl_sf_bessel_K1_scaled };

/*Using sf_bessel_Kn_scaled_e as pyton name*/
static void * sf_bessel_Kn_scaled_e_data [] = { (void *) gsl_sf_bessel_Kn_scaled_e, (void *) gsl_sf_bessel_Kn_scaled_e };

/*Using sf_bessel_Kn_scaled as pyton name*/
static void * sf_bessel_Kn_scaled_data [] = { (void *) gsl_sf_bessel_Kn_scaled, (void *) gsl_sf_bessel_Kn_scaled };

/*Using sf_bessel_j0_e as pyton name*/
static void * sf_bessel_j0_e_data [] = { (void *) gsl_sf_bessel_j0_e, (void *) gsl_sf_bessel_j0_e };

/*Using sf_bessel_j0 as pyton name*/
static void * sf_bessel_j0_data [] = { (void *) gsl_sf_bessel_j0, (void *) gsl_sf_bessel_j0 };

/*Using sf_bessel_j1_e as pyton name*/
static void * sf_bessel_j1_e_data [] = { (void *) gsl_sf_bessel_j1_e, (void *) gsl_sf_bessel_j1_e };

/*Using sf_bessel_j1 as pyton name*/
static void * sf_bessel_j1_data [] = { (void *) gsl_sf_bessel_j1, (void *) gsl_sf_bessel_j1 };

/*Using sf_bessel_j2_e as pyton name*/
static void * sf_bessel_j2_e_data [] = { (void *) gsl_sf_bessel_j2_e, (void *) gsl_sf_bessel_j2_e };

/*Using sf_bessel_j2 as pyton name*/
static void * sf_bessel_j2_data [] = { (void *) gsl_sf_bessel_j2, (void *) gsl_sf_bessel_j2 };

/*Using sf_bessel_jl_e as pyton name*/
static void * sf_bessel_jl_e_data [] = { (void *) gsl_sf_bessel_jl_e, (void *) gsl_sf_bessel_jl_e };

/*Using sf_bessel_jl as pyton name*/
static void * sf_bessel_jl_data [] = { (void *) gsl_sf_bessel_jl, (void *) gsl_sf_bessel_jl };

/*Using sf_bessel_y0_e as pyton name*/
static void * sf_bessel_y0_e_data [] = { (void *) gsl_sf_bessel_y0_e, (void *) gsl_sf_bessel_y0_e };

/*Using sf_bessel_y0 as pyton name*/
static void * sf_bessel_y0_data [] = { (void *) gsl_sf_bessel_y0, (void *) gsl_sf_bessel_y0 };

/*Using sf_bessel_y1_e as pyton name*/
static void * sf_bessel_y1_e_data [] = { (void *) gsl_sf_bessel_y1_e, (void *) gsl_sf_bessel_y1_e };

/*Using sf_bessel_y1 as pyton name*/
static void * sf_bessel_y1_data [] = { (void *) gsl_sf_bessel_y1, (void *) gsl_sf_bessel_y1 };

/*Using sf_bessel_y2_e as pyton name*/
static void * sf_bessel_y2_e_data [] = { (void *) gsl_sf_bessel_y2_e, (void *) gsl_sf_bessel_y2_e };

/*Using sf_bessel_y2 as pyton name*/
static void * sf_bessel_y2_data [] = { (void *) gsl_sf_bessel_y2, (void *) gsl_sf_bessel_y2 };

/*Using sf_bessel_yl_e as pyton name*/
static void * sf_bessel_yl_e_data [] = { (void *) gsl_sf_bessel_yl_e, (void *) gsl_sf_bessel_yl_e };

/*Using sf_bessel_yl as pyton name*/
static void * sf_bessel_yl_data [] = { (void *) gsl_sf_bessel_yl, (void *) gsl_sf_bessel_yl };

/*Using sf_bessel_i0_scaled_e as pyton name*/
static void * sf_bessel_i0_scaled_e_data [] = { (void *) gsl_sf_bessel_i0_scaled_e, (void *) gsl_sf_bessel_i0_scaled_e };

/*Using sf_bessel_i0_scaled as pyton name*/
static void * sf_bessel_i0_scaled_data [] = { (void *) gsl_sf_bessel_i0_scaled, (void *) gsl_sf_bessel_i0_scaled };

/*Using sf_bessel_i1_scaled_e as pyton name*/
static void * sf_bessel_i1_scaled_e_data [] = { (void *) gsl_sf_bessel_i1_scaled_e, (void *) gsl_sf_bessel_i1_scaled_e };

/*Using sf_bessel_i1_scaled as pyton name*/
static void * sf_bessel_i1_scaled_data [] = { (void *) gsl_sf_bessel_i1_scaled, (void *) gsl_sf_bessel_i1_scaled };

/*Using sf_bessel_i2_scaled_e as pyton name*/
static void * sf_bessel_i2_scaled_e_data [] = { (void *) gsl_sf_bessel_i2_scaled_e, (void *) gsl_sf_bessel_i2_scaled_e };

/*Using sf_bessel_i2_scaled as pyton name*/
static void * sf_bessel_i2_scaled_data [] = { (void *) gsl_sf_bessel_i2_scaled, (void *) gsl_sf_bessel_i2_scaled };

/*Using sf_bessel_il_scaled_e as pyton name*/
static void * sf_bessel_il_scaled_e_data [] = { (void *) gsl_sf_bessel_il_scaled_e, (void *) gsl_sf_bessel_il_scaled_e };

/*Using sf_bessel_il_scaled as pyton name*/
static void * sf_bessel_il_scaled_data [] = { (void *) gsl_sf_bessel_il_scaled, (void *) gsl_sf_bessel_il_scaled };

/*Using sf_bessel_k0_scaled_e as pyton name*/
static void * sf_bessel_k0_scaled_e_data [] = { (void *) gsl_sf_bessel_k0_scaled_e, (void *) gsl_sf_bessel_k0_scaled_e };

/*Using sf_bessel_k0_scaled as pyton name*/
static void * sf_bessel_k0_scaled_data [] = { (void *) gsl_sf_bessel_k0_scaled, (void *) gsl_sf_bessel_k0_scaled };

/*Using sf_bessel_k1_scaled_e as pyton name*/
static void * sf_bessel_k1_scaled_e_data [] = { (void *) gsl_sf_bessel_k1_scaled_e, (void *) gsl_sf_bessel_k1_scaled_e };

/*Using sf_bessel_k1_scaled as pyton name*/
static void * sf_bessel_k1_scaled_data [] = { (void *) gsl_sf_bessel_k1_scaled, (void *) gsl_sf_bessel_k1_scaled };

/*Using sf_bessel_k2_scaled_e as pyton name*/
static void * sf_bessel_k2_scaled_e_data [] = { (void *) gsl_sf_bessel_k2_scaled_e, (void *) gsl_sf_bessel_k2_scaled_e };

/*Using sf_bessel_k2_scaled as pyton name*/
static void * sf_bessel_k2_scaled_data [] = { (void *) gsl_sf_bessel_k2_scaled, (void *) gsl_sf_bessel_k2_scaled };

/*Using sf_bessel_kl_scaled_e as pyton name*/
static void * sf_bessel_kl_scaled_e_data [] = { (void *) gsl_sf_bessel_kl_scaled_e, (void *) gsl_sf_bessel_kl_scaled_e };

/*Using sf_bessel_kl_scaled as pyton name*/
static void * sf_bessel_kl_scaled_data [] = { (void *) gsl_sf_bessel_kl_scaled, (void *) gsl_sf_bessel_kl_scaled };

/*Using sf_bessel_Jnu_e as pyton name*/
static void * sf_bessel_Jnu_e_data [] = { (void *) gsl_sf_bessel_Jnu_e, (void *) gsl_sf_bessel_Jnu_e };

/*Using sf_bessel_Jnu as pyton name*/
static void * sf_bessel_Jnu_data [] = { (void *) gsl_sf_bessel_Jnu, (void *) gsl_sf_bessel_Jnu };

/*Using sf_bessel_Ynu_e as pyton name*/
static void * sf_bessel_Ynu_e_data [] = { (void *) gsl_sf_bessel_Ynu_e, (void *) gsl_sf_bessel_Ynu_e };

/*Using sf_bessel_Ynu as pyton name*/
static void * sf_bessel_Ynu_data [] = { (void *) gsl_sf_bessel_Ynu, (void *) gsl_sf_bessel_Ynu };

/*Using sf_bessel_Inu_scaled_e as pyton name*/
static void * sf_bessel_Inu_scaled_e_data [] = { (void *) gsl_sf_bessel_Inu_scaled_e, (void *) gsl_sf_bessel_Inu_scaled_e };

/*Using sf_bessel_Inu_scaled as pyton name*/
static void * sf_bessel_Inu_scaled_data [] = { (void *) gsl_sf_bessel_Inu_scaled, (void *) gsl_sf_bessel_Inu_scaled };

/*Using sf_bessel_Inu_e as pyton name*/
static void * sf_bessel_Inu_e_data [] = { (void *) gsl_sf_bessel_Inu_e, (void *) gsl_sf_bessel_Inu_e };

/*Using sf_bessel_Inu as pyton name*/
static void * sf_bessel_Inu_data [] = { (void *) gsl_sf_bessel_Inu, (void *) gsl_sf_bessel_Inu };

/*Using sf_bessel_Knu_scaled_e as pyton name*/
static void * sf_bessel_Knu_scaled_e_data [] = { (void *) gsl_sf_bessel_Knu_scaled_e, (void *) gsl_sf_bessel_Knu_scaled_e };

/*Using sf_bessel_Knu_scaled as pyton name*/
static void * sf_bessel_Knu_scaled_data [] = { (void *) gsl_sf_bessel_Knu_scaled, (void *) gsl_sf_bessel_Knu_scaled };

/*Using sf_bessel_Knu_e as pyton name*/
static void * sf_bessel_Knu_e_data [] = { (void *) gsl_sf_bessel_Knu_e, (void *) gsl_sf_bessel_Knu_e };

/*Using sf_bessel_Knu as pyton name*/
static void * sf_bessel_Knu_data [] = { (void *) gsl_sf_bessel_Knu, (void *) gsl_sf_bessel_Knu };

/*Using sf_bessel_lnKnu_e as pyton name*/
static void * sf_bessel_lnKnu_e_data [] = { (void *) gsl_sf_bessel_lnKnu_e, (void *) gsl_sf_bessel_lnKnu_e };

/*Using sf_bessel_lnKnu as pyton name*/
static void * sf_bessel_lnKnu_data [] = { (void *) gsl_sf_bessel_lnKnu, (void *) gsl_sf_bessel_lnKnu };

/*Using sf_bessel_zero_J0_e as pyton name*/
static void * sf_bessel_zero_J0_e_data [] = { (void *) gsl_sf_bessel_zero_J0_e, (void *) gsl_sf_bessel_zero_J0_e };

/*Using sf_bessel_zero_J0 as pyton name*/
static void * sf_bessel_zero_J0_data [] = { (void *) gsl_sf_bessel_zero_J0, (void *) gsl_sf_bessel_zero_J0 };

/*Using sf_bessel_zero_J1_e as pyton name*/
static void * sf_bessel_zero_J1_e_data [] = { (void *) gsl_sf_bessel_zero_J1_e, (void *) gsl_sf_bessel_zero_J1_e };

/*Using sf_bessel_zero_J1 as pyton name*/
static void * sf_bessel_zero_J1_data [] = { (void *) gsl_sf_bessel_zero_J1, (void *) gsl_sf_bessel_zero_J1 };

/*Using sf_bessel_zero_Jnu_e as pyton name*/
static void * sf_bessel_zero_Jnu_e_data [] = { (void *) gsl_sf_bessel_zero_Jnu_e, (void *) gsl_sf_bessel_zero_Jnu_e };

/*Using sf_bessel_zero_Jnu as pyton name*/
static void * sf_bessel_zero_Jnu_data [] = { (void *) gsl_sf_bessel_zero_Jnu, (void *) gsl_sf_bessel_zero_Jnu };

/*Using sf_clausen_e as pyton name*/
static void * sf_clausen_e_data [] = { (void *) gsl_sf_clausen_e, (void *) gsl_sf_clausen_e };

/*Using sf_clausen as pyton name*/
static void * sf_clausen_data [] = { (void *) gsl_sf_clausen, (void *) gsl_sf_clausen };

/*Using sf_coupling_3j_e as pyton name*/
static void * sf_coupling_3j_e_data [] = { (void *) gsl_sf_coupling_3j_e, (void *) gsl_sf_coupling_3j_e };

/*Using sf_coupling_3j as pyton name*/
static void * sf_coupling_3j_data [] = { (void *) gsl_sf_coupling_3j, (void *) gsl_sf_coupling_3j };

/*Using sf_coupling_6j_e as pyton name*/
static void * sf_coupling_6j_e_data [] = { (void *) gsl_sf_coupling_6j_e, (void *) gsl_sf_coupling_6j_e };

/*Using sf_coupling_6j as pyton name*/
static void * sf_coupling_6j_data [] = { (void *) gsl_sf_coupling_6j, (void *) gsl_sf_coupling_6j };

/*Using sf_coupling_RacahW_e as pyton name*/
static void * sf_coupling_RacahW_e_data [] = { (void *) gsl_sf_coupling_RacahW_e, (void *) gsl_sf_coupling_RacahW_e };

/*Using sf_coupling_RacahW as pyton name*/
static void * sf_coupling_RacahW_data [] = { (void *) gsl_sf_coupling_RacahW, (void *) gsl_sf_coupling_RacahW };

/*Using sf_coupling_9j_e as pyton name*/
static void * sf_coupling_9j_e_data [] = { (void *) gsl_sf_coupling_9j_e, (void *) gsl_sf_coupling_9j_e };

/*Using sf_coupling_9j as pyton name*/
static void * sf_coupling_9j_data [] = { (void *) gsl_sf_coupling_9j, (void *) gsl_sf_coupling_9j };

/*Using sf_coupling_6j_INCORRECT as pyton name*/
static void * sf_coupling_6j_INCORRECT_data [] = { (void *) gsl_sf_coupling_6j_INCORRECT, (void *) gsl_sf_coupling_6j_INCORRECT };

/*Using sf_hydrogenicR_1_e as pyton name*/
static void * sf_hydrogenicR_1_e_data [] = { (void *) gsl_sf_hydrogenicR_1_e, (void *) gsl_sf_hydrogenicR_1_e };

/*Using sf_hydrogenicR_1 as pyton name*/
static void * sf_hydrogenicR_1_data [] = { (void *) gsl_sf_hydrogenicR_1, (void *) gsl_sf_hydrogenicR_1 };

/*Using sf_hydrogenicR_e as pyton name*/
static void * sf_hydrogenicR_e_data [] = { (void *) gsl_sf_hydrogenicR_e, (void *) gsl_sf_hydrogenicR_e };

/*Using sf_hydrogenicR as pyton name*/
static void * sf_hydrogenicR_data [] = { (void *) gsl_sf_hydrogenicR, (void *) gsl_sf_hydrogenicR };

/*Using sf_coulomb_wave_FG_e as pyton name*/
static void * sf_coulomb_wave_FG_e_data [] = { (void *) gsl_sf_coulomb_wave_FG_e, (void *) gsl_sf_coulomb_wave_FG_e };

/*Using sf_coulomb_CL_e as pyton name*/
static void * sf_coulomb_CL_e_data [] = { (void *) gsl_sf_coulomb_CL_e, (void *) gsl_sf_coulomb_CL_e };

/*Using sf_dawson_e as pyton name*/
static void * sf_dawson_e_data [] = { (void *) gsl_sf_dawson_e, (void *) gsl_sf_dawson_e };

/*Using sf_dawson as pyton name*/
static void * sf_dawson_data [] = { (void *) gsl_sf_dawson, (void *) gsl_sf_dawson };

/*Using sf_debye_1_e as pyton name*/
static void * sf_debye_1_e_data [] = { (void *) gsl_sf_debye_1_e, (void *) gsl_sf_debye_1_e };

/*Using sf_debye_1 as pyton name*/
static void * sf_debye_1_data [] = { (void *) gsl_sf_debye_1, (void *) gsl_sf_debye_1 };

/*Using sf_debye_2_e as pyton name*/
static void * sf_debye_2_e_data [] = { (void *) gsl_sf_debye_2_e, (void *) gsl_sf_debye_2_e };

/*Using sf_debye_2 as pyton name*/
static void * sf_debye_2_data [] = { (void *) gsl_sf_debye_2, (void *) gsl_sf_debye_2 };

/*Using sf_debye_3_e as pyton name*/
static void * sf_debye_3_e_data [] = { (void *) gsl_sf_debye_3_e, (void *) gsl_sf_debye_3_e };

/*Using sf_debye_3 as pyton name*/
static void * sf_debye_3_data [] = { (void *) gsl_sf_debye_3, (void *) gsl_sf_debye_3 };

/*Using sf_debye_4_e as pyton name*/
static void * sf_debye_4_e_data [] = { (void *) gsl_sf_debye_4_e, (void *) gsl_sf_debye_4_e };

/*Using sf_debye_4 as pyton name*/
static void * sf_debye_4_data [] = { (void *) gsl_sf_debye_4, (void *) gsl_sf_debye_4 };

/*Using sf_debye_5_e as pyton name*/
static void * sf_debye_5_e_data [] = { (void *) gsl_sf_debye_5_e, (void *) gsl_sf_debye_5_e };

/*Using sf_debye_5 as pyton name*/
static void * sf_debye_5_data [] = { (void *) gsl_sf_debye_5, (void *) gsl_sf_debye_5 };

/*Using sf_debye_6_e as pyton name*/
static void * sf_debye_6_e_data [] = { (void *) gsl_sf_debye_6_e, (void *) gsl_sf_debye_6_e };

/*Using sf_debye_6 as pyton name*/
static void * sf_debye_6_data [] = { (void *) gsl_sf_debye_6, (void *) gsl_sf_debye_6 };

/*Using sf_dilog_e as pyton name*/
static void * sf_dilog_e_data [] = { (void *) gsl_sf_dilog_e, (void *) gsl_sf_dilog_e };

/*Using sf_dilog as pyton name*/
static void * sf_dilog_data [] = { (void *) gsl_sf_dilog, (void *) gsl_sf_dilog };

/*Using sf_complex_dilog_xy_e as pyton name*/
static void * sf_complex_dilog_xy_e_data [] = { (void *) gsl_sf_complex_dilog_xy_e, (void *) gsl_sf_complex_dilog_xy_e };

/*Using sf_complex_spence_xy_e as pyton name*/
static void * sf_complex_spence_xy_e_data [] = { (void *) gsl_sf_complex_spence_xy_e, (void *) gsl_sf_complex_spence_xy_e };

/*Using sf_multiply_e as pyton name*/
static void * sf_multiply_e_data [] = { (void *) gsl_sf_multiply_e, (void *) gsl_sf_multiply_e };

/*Using sf_multiply as pyton name*/
static void * sf_multiply_data [] = { (void *) gsl_sf_multiply, (void *) gsl_sf_multiply };

/*Using sf_multiply_err_e as pyton name*/
static void * sf_multiply_err_e_data [] = { (void *) gsl_sf_multiply_err_e, (void *) gsl_sf_multiply_err_e };

/*Using sf_ellint_Kcomp_e as pyton name*/
static void * sf_ellint_Kcomp_e_data [] = { (void *) gsl_sf_ellint_Kcomp_e, (void *) gsl_sf_ellint_Kcomp_e };

/*Using sf_ellint_Kcomp as pyton name*/
static void * sf_ellint_Kcomp_data [] = { (void *) gsl_sf_ellint_Kcomp, (void *) gsl_sf_ellint_Kcomp };

/*Using sf_ellint_Ecomp_e as pyton name*/
static void * sf_ellint_Ecomp_e_data [] = { (void *) gsl_sf_ellint_Ecomp_e, (void *) gsl_sf_ellint_Ecomp_e };

/*Using sf_ellint_Ecomp as pyton name*/
static void * sf_ellint_Ecomp_data [] = { (void *) gsl_sf_ellint_Ecomp, (void *) gsl_sf_ellint_Ecomp };

/*Using sf_ellint_Pcomp_e as pyton name*/
static void * sf_ellint_Pcomp_e_data [] = { (void *) gsl_sf_ellint_Pcomp_e, (void *) gsl_sf_ellint_Pcomp_e };

/*Using sf_ellint_Pcomp as pyton name*/
static void * sf_ellint_Pcomp_data [] = { (void *) gsl_sf_ellint_Pcomp, (void *) gsl_sf_ellint_Pcomp };

/*Using sf_ellint_Dcomp_e as pyton name*/
static void * sf_ellint_Dcomp_e_data [] = { (void *) gsl_sf_ellint_Dcomp_e, (void *) gsl_sf_ellint_Dcomp_e };

/*Using sf_ellint_Dcomp as pyton name*/
static void * sf_ellint_Dcomp_data [] = { (void *) gsl_sf_ellint_Dcomp, (void *) gsl_sf_ellint_Dcomp };

/*Using sf_ellint_F_e as pyton name*/
static void * sf_ellint_F_e_data [] = { (void *) gsl_sf_ellint_F_e, (void *) gsl_sf_ellint_F_e };

/*Using sf_ellint_F as pyton name*/
static void * sf_ellint_F_data [] = { (void *) gsl_sf_ellint_F, (void *) gsl_sf_ellint_F };

/*Using sf_ellint_E_e as pyton name*/
static void * sf_ellint_E_e_data [] = { (void *) gsl_sf_ellint_E_e, (void *) gsl_sf_ellint_E_e };

/*Using sf_ellint_E as pyton name*/
static void * sf_ellint_E_data [] = { (void *) gsl_sf_ellint_E, (void *) gsl_sf_ellint_E };

/*Using sf_ellint_P_e as pyton name*/
static void * sf_ellint_P_e_data [] = { (void *) gsl_sf_ellint_P_e, (void *) gsl_sf_ellint_P_e };

/*Using sf_ellint_P as pyton name*/
static void * sf_ellint_P_data [] = { (void *) gsl_sf_ellint_P, (void *) gsl_sf_ellint_P };

/*Using sf_ellint_D_e as pyton name*/
static void * sf_ellint_D_e_data [] = { (void *) gsl_sf_ellint_D_e, (void *) gsl_sf_ellint_D_e };

/*Using sf_ellint_D as pyton name*/
static void * sf_ellint_D_data [] = { (void *) gsl_sf_ellint_D, (void *) gsl_sf_ellint_D };

/*Using sf_ellint_RC_e as pyton name*/
static void * sf_ellint_RC_e_data [] = { (void *) gsl_sf_ellint_RC_e, (void *) gsl_sf_ellint_RC_e };

/*Using sf_ellint_RC as pyton name*/
static void * sf_ellint_RC_data [] = { (void *) gsl_sf_ellint_RC, (void *) gsl_sf_ellint_RC };

/*Using sf_ellint_RD_e as pyton name*/
static void * sf_ellint_RD_e_data [] = { (void *) gsl_sf_ellint_RD_e, (void *) gsl_sf_ellint_RD_e };

/*Using sf_ellint_RD as pyton name*/
static void * sf_ellint_RD_data [] = { (void *) gsl_sf_ellint_RD, (void *) gsl_sf_ellint_RD };

/*Using sf_ellint_RF_e as pyton name*/
static void * sf_ellint_RF_e_data [] = { (void *) gsl_sf_ellint_RF_e, (void *) gsl_sf_ellint_RF_e };

/*Using sf_ellint_RF as pyton name*/
static void * sf_ellint_RF_data [] = { (void *) gsl_sf_ellint_RF, (void *) gsl_sf_ellint_RF };

/*Using sf_ellint_RJ_e as pyton name*/
static void * sf_ellint_RJ_e_data [] = { (void *) gsl_sf_ellint_RJ_e, (void *) gsl_sf_ellint_RJ_e };

/*Using sf_ellint_RJ as pyton name*/
static void * sf_ellint_RJ_data [] = { (void *) gsl_sf_ellint_RJ, (void *) gsl_sf_ellint_RJ };

/*Using sf_elljac_e as pyton name*/
static void * sf_elljac_e_data [] = { (void *) gsl_sf_elljac_e, (void *) gsl_sf_elljac_e };

/*Using sf_erfc_e as pyton name*/
static void * sf_erfc_e_data [] = { (void *) gsl_sf_erfc_e, (void *) gsl_sf_erfc_e };

/*Using sf_erfc as pyton name*/
static void * sf_erfc_data [] = { (void *) gsl_sf_erfc, (void *) gsl_sf_erfc };

/*Using sf_log_erfc_e as pyton name*/
static void * sf_log_erfc_e_data [] = { (void *) gsl_sf_log_erfc_e, (void *) gsl_sf_log_erfc_e };

/*Using sf_log_erfc as pyton name*/
static void * sf_log_erfc_data [] = { (void *) gsl_sf_log_erfc, (void *) gsl_sf_log_erfc };

/*Using sf_erf_e as pyton name*/
static void * sf_erf_e_data [] = { (void *) gsl_sf_erf_e, (void *) gsl_sf_erf_e };

/*Using sf_erf as pyton name*/
static void * sf_erf_data [] = { (void *) gsl_sf_erf, (void *) gsl_sf_erf };

/*Using sf_erf_Z_e as pyton name*/
static void * sf_erf_Z_e_data [] = { (void *) gsl_sf_erf_Z_e, (void *) gsl_sf_erf_Z_e };

/*Using sf_erf_Q_e as pyton name*/
static void * sf_erf_Q_e_data [] = { (void *) gsl_sf_erf_Q_e, (void *) gsl_sf_erf_Q_e };

/*Using sf_erf_Z as pyton name*/
static void * sf_erf_Z_data [] = { (void *) gsl_sf_erf_Z, (void *) gsl_sf_erf_Z };

/*Using sf_erf_Q as pyton name*/
static void * sf_erf_Q_data [] = { (void *) gsl_sf_erf_Q, (void *) gsl_sf_erf_Q };

/*Using sf_hazard_e as pyton name*/
static void * sf_hazard_e_data [] = { (void *) gsl_sf_hazard_e, (void *) gsl_sf_hazard_e };

/*Using sf_hazard as pyton name*/
static void * sf_hazard_data [] = { (void *) gsl_sf_hazard, (void *) gsl_sf_hazard };

/*Using sf_exp_e as pyton name*/
static void * sf_exp_e_data [] = { (void *) gsl_sf_exp_e, (void *) gsl_sf_exp_e };

/*Using sf_exp as pyton name*/
static void * sf_exp_data [] = { (void *) gsl_sf_exp, (void *) gsl_sf_exp };

/*Using sf_exp_e10_e as pyton name*/
static void * sf_exp_e10_e_data [] = { (void *) gsl_sf_exp_e10_e, (void *) gsl_sf_exp_e10_e };

/*Using sf_exp_mult_e as pyton name*/
static void * sf_exp_mult_e_data [] = { (void *) gsl_sf_exp_mult_e, (void *) gsl_sf_exp_mult_e };

/*Using sf_exp_mult as pyton name*/
static void * sf_exp_mult_data [] = { (void *) gsl_sf_exp_mult, (void *) gsl_sf_exp_mult };

/*Using sf_exp_mult_e10_e as pyton name*/
static void * sf_exp_mult_e10_e_data [] = { (void *) gsl_sf_exp_mult_e10_e, (void *) gsl_sf_exp_mult_e10_e };

/*Using sf_expm1_e as pyton name*/
static void * sf_expm1_e_data [] = { (void *) gsl_sf_expm1_e, (void *) gsl_sf_expm1_e };

/*Using sf_expm1 as pyton name*/
static void * sf_expm1_data [] = { (void *) gsl_sf_expm1, (void *) gsl_sf_expm1 };

/*Using sf_exprel_e as pyton name*/
static void * sf_exprel_e_data [] = { (void *) gsl_sf_exprel_e, (void *) gsl_sf_exprel_e };

/*Using sf_exprel as pyton name*/
static void * sf_exprel_data [] = { (void *) gsl_sf_exprel, (void *) gsl_sf_exprel };

/*Using sf_exprel_2_e as pyton name*/
static void * sf_exprel_2_e_data [] = { (void *) gsl_sf_exprel_2_e, (void *) gsl_sf_exprel_2_e };

/*Using sf_exprel_2 as pyton name*/
static void * sf_exprel_2_data [] = { (void *) gsl_sf_exprel_2, (void *) gsl_sf_exprel_2 };

/*Using sf_exprel_n_e as pyton name*/
static void * sf_exprel_n_e_data [] = { (void *) gsl_sf_exprel_n_e, (void *) gsl_sf_exprel_n_e };

/*Using sf_exprel_n as pyton name*/
static void * sf_exprel_n_data [] = { (void *) gsl_sf_exprel_n, (void *) gsl_sf_exprel_n };

/*Using sf_exprel_n_CF_e as pyton name*/
static void * sf_exprel_n_CF_e_data [] = { (void *) gsl_sf_exprel_n_CF_e, (void *) gsl_sf_exprel_n_CF_e };

/*Using sf_exp_err_e as pyton name*/
static void * sf_exp_err_e_data [] = { (void *) gsl_sf_exp_err_e, (void *) gsl_sf_exp_err_e };

/*Using sf_exp_err_e10_e as pyton name*/
static void * sf_exp_err_e10_e_data [] = { (void *) gsl_sf_exp_err_e10_e, (void *) gsl_sf_exp_err_e10_e };

/*Using sf_exp_mult_err_e as pyton name*/
static void * sf_exp_mult_err_e_data [] = { (void *) gsl_sf_exp_mult_err_e, (void *) gsl_sf_exp_mult_err_e };

/*Using sf_exp_mult_err_e10_e as pyton name*/
static void * sf_exp_mult_err_e10_e_data [] = { (void *) gsl_sf_exp_mult_err_e10_e, (void *) gsl_sf_exp_mult_err_e10_e };

/*Using sf_expint_E1_e as pyton name*/
static void * sf_expint_E1_e_data [] = { (void *) gsl_sf_expint_E1_e, (void *) gsl_sf_expint_E1_e };

/*Using sf_expint_E1 as pyton name*/
static void * sf_expint_E1_data [] = { (void *) gsl_sf_expint_E1, (void *) gsl_sf_expint_E1 };

/*Using sf_expint_E2_e as pyton name*/
static void * sf_expint_E2_e_data [] = { (void *) gsl_sf_expint_E2_e, (void *) gsl_sf_expint_E2_e };

/*Using sf_expint_E2 as pyton name*/
static void * sf_expint_E2_data [] = { (void *) gsl_sf_expint_E2, (void *) gsl_sf_expint_E2 };

/*Using sf_expint_En_e as pyton name*/
static void * sf_expint_En_e_data [] = { (void *) gsl_sf_expint_En_e, (void *) gsl_sf_expint_En_e };

/*Using sf_expint_En as pyton name*/
static void * sf_expint_En_data [] = { (void *) gsl_sf_expint_En, (void *) gsl_sf_expint_En };

/*Using sf_expint_E1_scaled_e as pyton name*/
static void * sf_expint_E1_scaled_e_data [] = { (void *) gsl_sf_expint_E1_scaled_e, (void *) gsl_sf_expint_E1_scaled_e };

/*Using sf_expint_E1_scaled as pyton name*/
static void * sf_expint_E1_scaled_data [] = { (void *) gsl_sf_expint_E1_scaled, (void *) gsl_sf_expint_E1_scaled };

/*Using sf_expint_E2_scaled_e as pyton name*/
static void * sf_expint_E2_scaled_e_data [] = { (void *) gsl_sf_expint_E2_scaled_e, (void *) gsl_sf_expint_E2_scaled_e };

/*Using sf_expint_E2_scaled as pyton name*/
static void * sf_expint_E2_scaled_data [] = { (void *) gsl_sf_expint_E2_scaled, (void *) gsl_sf_expint_E2_scaled };

/*Using sf_expint_En_scaled_e as pyton name*/
static void * sf_expint_En_scaled_e_data [] = { (void *) gsl_sf_expint_En_scaled_e, (void *) gsl_sf_expint_En_scaled_e };

/*Using sf_expint_En_scaled as pyton name*/
static void * sf_expint_En_scaled_data [] = { (void *) gsl_sf_expint_En_scaled, (void *) gsl_sf_expint_En_scaled };

/*Using sf_expint_Ei_e as pyton name*/
static void * sf_expint_Ei_e_data [] = { (void *) gsl_sf_expint_Ei_e, (void *) gsl_sf_expint_Ei_e };

/*Using sf_expint_Ei as pyton name*/
static void * sf_expint_Ei_data [] = { (void *) gsl_sf_expint_Ei, (void *) gsl_sf_expint_Ei };

/*Using sf_expint_Ei_scaled_e as pyton name*/
static void * sf_expint_Ei_scaled_e_data [] = { (void *) gsl_sf_expint_Ei_scaled_e, (void *) gsl_sf_expint_Ei_scaled_e };

/*Using sf_expint_Ei_scaled as pyton name*/
static void * sf_expint_Ei_scaled_data [] = { (void *) gsl_sf_expint_Ei_scaled, (void *) gsl_sf_expint_Ei_scaled };

/*Using sf_Shi_e as pyton name*/
static void * sf_Shi_e_data [] = { (void *) gsl_sf_Shi_e, (void *) gsl_sf_Shi_e };

/*Using sf_Shi as pyton name*/
static void * sf_Shi_data [] = { (void *) gsl_sf_Shi, (void *) gsl_sf_Shi };

/*Using sf_Chi_e as pyton name*/
static void * sf_Chi_e_data [] = { (void *) gsl_sf_Chi_e, (void *) gsl_sf_Chi_e };

/*Using sf_Chi as pyton name*/
static void * sf_Chi_data [] = { (void *) gsl_sf_Chi, (void *) gsl_sf_Chi };

/*Using sf_expint_3_e as pyton name*/
static void * sf_expint_3_e_data [] = { (void *) gsl_sf_expint_3_e, (void *) gsl_sf_expint_3_e };

/*Using sf_expint_3 as pyton name*/
static void * sf_expint_3_data [] = { (void *) gsl_sf_expint_3, (void *) gsl_sf_expint_3 };

/*Using sf_Si_e as pyton name*/
static void * sf_Si_e_data [] = { (void *) gsl_sf_Si_e, (void *) gsl_sf_Si_e };

/*Using sf_Si as pyton name*/
static void * sf_Si_data [] = { (void *) gsl_sf_Si, (void *) gsl_sf_Si };

/*Using sf_Ci_e as pyton name*/
static void * sf_Ci_e_data [] = { (void *) gsl_sf_Ci_e, (void *) gsl_sf_Ci_e };

/*Using sf_Ci as pyton name*/
static void * sf_Ci_data [] = { (void *) gsl_sf_Ci, (void *) gsl_sf_Ci };

/*Using sf_atanint_e as pyton name*/
static void * sf_atanint_e_data [] = { (void *) gsl_sf_atanint_e, (void *) gsl_sf_atanint_e };

/*Using sf_atanint as pyton name*/
static void * sf_atanint_data [] = { (void *) gsl_sf_atanint, (void *) gsl_sf_atanint };

/*Using sf_fermi_dirac_m1_e as pyton name*/
static void * sf_fermi_dirac_m1_e_data [] = { (void *) gsl_sf_fermi_dirac_m1_e, (void *) gsl_sf_fermi_dirac_m1_e };

/*Using sf_fermi_dirac_m1 as pyton name*/
static void * sf_fermi_dirac_m1_data [] = { (void *) gsl_sf_fermi_dirac_m1, (void *) gsl_sf_fermi_dirac_m1 };

/*Using sf_fermi_dirac_0_e as pyton name*/
static void * sf_fermi_dirac_0_e_data [] = { (void *) gsl_sf_fermi_dirac_0_e, (void *) gsl_sf_fermi_dirac_0_e };

/*Using sf_fermi_dirac_0 as pyton name*/
static void * sf_fermi_dirac_0_data [] = { (void *) gsl_sf_fermi_dirac_0, (void *) gsl_sf_fermi_dirac_0 };

/*Using sf_fermi_dirac_1_e as pyton name*/
static void * sf_fermi_dirac_1_e_data [] = { (void *) gsl_sf_fermi_dirac_1_e, (void *) gsl_sf_fermi_dirac_1_e };

/*Using sf_fermi_dirac_1 as pyton name*/
static void * sf_fermi_dirac_1_data [] = { (void *) gsl_sf_fermi_dirac_1, (void *) gsl_sf_fermi_dirac_1 };

/*Using sf_fermi_dirac_2_e as pyton name*/
static void * sf_fermi_dirac_2_e_data [] = { (void *) gsl_sf_fermi_dirac_2_e, (void *) gsl_sf_fermi_dirac_2_e };

/*Using sf_fermi_dirac_2 as pyton name*/
static void * sf_fermi_dirac_2_data [] = { (void *) gsl_sf_fermi_dirac_2, (void *) gsl_sf_fermi_dirac_2 };

/*Using sf_fermi_dirac_int_e as pyton name*/
static void * sf_fermi_dirac_int_e_data [] = { (void *) gsl_sf_fermi_dirac_int_e, (void *) gsl_sf_fermi_dirac_int_e };

/*Using sf_fermi_dirac_int as pyton name*/
static void * sf_fermi_dirac_int_data [] = { (void *) gsl_sf_fermi_dirac_int, (void *) gsl_sf_fermi_dirac_int };

/*Using sf_fermi_dirac_mhalf_e as pyton name*/
static void * sf_fermi_dirac_mhalf_e_data [] = { (void *) gsl_sf_fermi_dirac_mhalf_e, (void *) gsl_sf_fermi_dirac_mhalf_e };

/*Using sf_fermi_dirac_mhalf as pyton name*/
static void * sf_fermi_dirac_mhalf_data [] = { (void *) gsl_sf_fermi_dirac_mhalf, (void *) gsl_sf_fermi_dirac_mhalf };

/*Using sf_fermi_dirac_half_e as pyton name*/
static void * sf_fermi_dirac_half_e_data [] = { (void *) gsl_sf_fermi_dirac_half_e, (void *) gsl_sf_fermi_dirac_half_e };

/*Using sf_fermi_dirac_half as pyton name*/
static void * sf_fermi_dirac_half_data [] = { (void *) gsl_sf_fermi_dirac_half, (void *) gsl_sf_fermi_dirac_half };

/*Using sf_fermi_dirac_3half_e as pyton name*/
static void * sf_fermi_dirac_3half_e_data [] = { (void *) gsl_sf_fermi_dirac_3half_e, (void *) gsl_sf_fermi_dirac_3half_e };

/*Using sf_fermi_dirac_3half as pyton name*/
static void * sf_fermi_dirac_3half_data [] = { (void *) gsl_sf_fermi_dirac_3half, (void *) gsl_sf_fermi_dirac_3half };

/*Using sf_fermi_dirac_inc_0_e as pyton name*/
static void * sf_fermi_dirac_inc_0_e_data [] = { (void *) gsl_sf_fermi_dirac_inc_0_e, (void *) gsl_sf_fermi_dirac_inc_0_e };

/*Using sf_fermi_dirac_inc_0 as pyton name*/
static void * sf_fermi_dirac_inc_0_data [] = { (void *) gsl_sf_fermi_dirac_inc_0, (void *) gsl_sf_fermi_dirac_inc_0 };

/*Using sf_lngamma_e as pyton name*/
static void * sf_lngamma_e_data [] = { (void *) gsl_sf_lngamma_e, (void *) gsl_sf_lngamma_e };

/*Using sf_lngamma as pyton name*/
static void * sf_lngamma_data [] = { (void *) gsl_sf_lngamma, (void *) gsl_sf_lngamma };

/*Using sf_lngamma_sgn_e as pyton name*/
static void * sf_lngamma_sgn_e_data [] = { (void *) gsl_sf_lngamma_sgn_e, (void *) gsl_sf_lngamma_sgn_e };

/*Using sf_gamma_e as pyton name*/
static void * sf_gamma_e_data [] = { (void *) gsl_sf_gamma_e, (void *) gsl_sf_gamma_e };

/*Using sf_gamma as pyton name*/
static void * sf_gamma_data [] = { (void *) gsl_sf_gamma, (void *) gsl_sf_gamma };

/*Using sf_gammastar_e as pyton name*/
static void * sf_gammastar_e_data [] = { (void *) gsl_sf_gammastar_e, (void *) gsl_sf_gammastar_e };

/*Using sf_gammastar as pyton name*/
static void * sf_gammastar_data [] = { (void *) gsl_sf_gammastar, (void *) gsl_sf_gammastar };

/*Using sf_gammainv_e as pyton name*/
static void * sf_gammainv_e_data [] = { (void *) gsl_sf_gammainv_e, (void *) gsl_sf_gammainv_e };

/*Using sf_gammainv as pyton name*/
static void * sf_gammainv_data [] = { (void *) gsl_sf_gammainv, (void *) gsl_sf_gammainv };

/*Using sf_taylorcoeff_e as pyton name*/
static void * sf_taylorcoeff_e_data [] = { (void *) gsl_sf_taylorcoeff_e, (void *) gsl_sf_taylorcoeff_e };

/*Using sf_taylorcoeff as pyton name*/
static void * sf_taylorcoeff_data [] = { (void *) gsl_sf_taylorcoeff, (void *) gsl_sf_taylorcoeff };

/*Using sf_fact_e as pyton name*/
static void * sf_fact_e_data [] = { (void *) gsl_sf_fact_e, (void *) gsl_sf_fact_e };

/*Using sf_fact as pyton name*/
static void * sf_fact_data [] = { (void *) gsl_sf_fact, (void *) gsl_sf_fact };

/*Using sf_doublefact_e as pyton name*/
static void * sf_doublefact_e_data [] = { (void *) gsl_sf_doublefact_e, (void *) gsl_sf_doublefact_e };

/*Using sf_doublefact as pyton name*/
static void * sf_doublefact_data [] = { (void *) gsl_sf_doublefact, (void *) gsl_sf_doublefact };

/*Using sf_lnfact_e as pyton name*/
static void * sf_lnfact_e_data [] = { (void *) gsl_sf_lnfact_e, (void *) gsl_sf_lnfact_e };

/*Using sf_lnfact as pyton name*/
static void * sf_lnfact_data [] = { (void *) gsl_sf_lnfact, (void *) gsl_sf_lnfact };

/*Using sf_lndoublefact_e as pyton name*/
static void * sf_lndoublefact_e_data [] = { (void *) gsl_sf_lndoublefact_e, (void *) gsl_sf_lndoublefact_e };

/*Using sf_lndoublefact as pyton name*/
static void * sf_lndoublefact_data [] = { (void *) gsl_sf_lndoublefact, (void *) gsl_sf_lndoublefact };

/*Using sf_lnchoose_e as pyton name*/
static void * sf_lnchoose_e_data [] = { (void *) gsl_sf_lnchoose_e, (void *) gsl_sf_lnchoose_e };

/*Using sf_lnchoose as pyton name*/
static void * sf_lnchoose_data [] = { (void *) gsl_sf_lnchoose, (void *) gsl_sf_lnchoose };

/*Using sf_choose_e as pyton name*/
static void * sf_choose_e_data [] = { (void *) gsl_sf_choose_e, (void *) gsl_sf_choose_e };

/*Using sf_choose as pyton name*/
static void * sf_choose_data [] = { (void *) gsl_sf_choose, (void *) gsl_sf_choose };

/*Using sf_lnpoch_e as pyton name*/
static void * sf_lnpoch_e_data [] = { (void *) gsl_sf_lnpoch_e, (void *) gsl_sf_lnpoch_e };

/*Using sf_lnpoch as pyton name*/
static void * sf_lnpoch_data [] = { (void *) gsl_sf_lnpoch, (void *) gsl_sf_lnpoch };

/*Using sf_lnpoch_sgn_e as pyton name*/
static void * sf_lnpoch_sgn_e_data [] = { (void *) gsl_sf_lnpoch_sgn_e, (void *) gsl_sf_lnpoch_sgn_e };

/*Using sf_poch_e as pyton name*/
static void * sf_poch_e_data [] = { (void *) gsl_sf_poch_e, (void *) gsl_sf_poch_e };

/*Using sf_poch as pyton name*/
static void * sf_poch_data [] = { (void *) gsl_sf_poch, (void *) gsl_sf_poch };

/*Using sf_pochrel_e as pyton name*/
static void * sf_pochrel_e_data [] = { (void *) gsl_sf_pochrel_e, (void *) gsl_sf_pochrel_e };

/*Using sf_pochrel as pyton name*/
static void * sf_pochrel_data [] = { (void *) gsl_sf_pochrel, (void *) gsl_sf_pochrel };

/*Using sf_gamma_inc_Q_e as pyton name*/
static void * sf_gamma_inc_Q_e_data [] = { (void *) gsl_sf_gamma_inc_Q_e, (void *) gsl_sf_gamma_inc_Q_e };

/*Using sf_gamma_inc_Q as pyton name*/
static void * sf_gamma_inc_Q_data [] = { (void *) gsl_sf_gamma_inc_Q, (void *) gsl_sf_gamma_inc_Q };

/*Using sf_gamma_inc_P_e as pyton name*/
static void * sf_gamma_inc_P_e_data [] = { (void *) gsl_sf_gamma_inc_P_e, (void *) gsl_sf_gamma_inc_P_e };

/*Using sf_gamma_inc_P as pyton name*/
static void * sf_gamma_inc_P_data [] = { (void *) gsl_sf_gamma_inc_P, (void *) gsl_sf_gamma_inc_P };

/*Using sf_gamma_inc_e as pyton name*/
static void * sf_gamma_inc_e_data [] = { (void *) gsl_sf_gamma_inc_e, (void *) gsl_sf_gamma_inc_e };

/*Using sf_gamma_inc as pyton name*/
static void * sf_gamma_inc_data [] = { (void *) gsl_sf_gamma_inc, (void *) gsl_sf_gamma_inc };

/*Using sf_lnbeta_e as pyton name*/
static void * sf_lnbeta_e_data [] = { (void *) gsl_sf_lnbeta_e, (void *) gsl_sf_lnbeta_e };

/*Using sf_lnbeta as pyton name*/
static void * sf_lnbeta_data [] = { (void *) gsl_sf_lnbeta, (void *) gsl_sf_lnbeta };

/*Using sf_lnbeta_sgn_e as pyton name*/
static void * sf_lnbeta_sgn_e_data [] = { (void *) gsl_sf_lnbeta_sgn_e, (void *) gsl_sf_lnbeta_sgn_e };

/*Using sf_beta_e as pyton name*/
static void * sf_beta_e_data [] = { (void *) gsl_sf_beta_e, (void *) gsl_sf_beta_e };

/*Using sf_beta as pyton name*/
static void * sf_beta_data [] = { (void *) gsl_sf_beta, (void *) gsl_sf_beta };

/*Using sf_beta_inc_e as pyton name*/
static void * sf_beta_inc_e_data [] = { (void *) gsl_sf_beta_inc_e, (void *) gsl_sf_beta_inc_e };

/*Using sf_beta_inc as pyton name*/
static void * sf_beta_inc_data [] = { (void *) gsl_sf_beta_inc, (void *) gsl_sf_beta_inc };

/*Using sf_gegenpoly_1_e as pyton name*/
static void * sf_gegenpoly_1_e_data [] = { (void *) gsl_sf_gegenpoly_1_e, (void *) gsl_sf_gegenpoly_1_e };

/*Using sf_gegenpoly_2_e as pyton name*/
static void * sf_gegenpoly_2_e_data [] = { (void *) gsl_sf_gegenpoly_2_e, (void *) gsl_sf_gegenpoly_2_e };

/*Using sf_gegenpoly_3_e as pyton name*/
static void * sf_gegenpoly_3_e_data [] = { (void *) gsl_sf_gegenpoly_3_e, (void *) gsl_sf_gegenpoly_3_e };

/*Using sf_gegenpoly_1 as pyton name*/
static void * sf_gegenpoly_1_data [] = { (void *) gsl_sf_gegenpoly_1, (void *) gsl_sf_gegenpoly_1 };

/*Using sf_gegenpoly_2 as pyton name*/
static void * sf_gegenpoly_2_data [] = { (void *) gsl_sf_gegenpoly_2, (void *) gsl_sf_gegenpoly_2 };

/*Using sf_gegenpoly_3 as pyton name*/
static void * sf_gegenpoly_3_data [] = { (void *) gsl_sf_gegenpoly_3, (void *) gsl_sf_gegenpoly_3 };

/*Using sf_gegenpoly_n_e as pyton name*/
static void * sf_gegenpoly_n_e_data [] = { (void *) gsl_sf_gegenpoly_n_e, (void *) gsl_sf_gegenpoly_n_e };

/*Using sf_gegenpoly_n as pyton name*/
static void * sf_gegenpoly_n_data [] = { (void *) gsl_sf_gegenpoly_n, (void *) gsl_sf_gegenpoly_n };

/*Using sf_hyperg_0F1_e as pyton name*/
static void * sf_hyperg_0F1_e_data [] = { (void *) gsl_sf_hyperg_0F1_e, (void *) gsl_sf_hyperg_0F1_e };

/*Using sf_hyperg_0F1 as pyton name*/
static void * sf_hyperg_0F1_data [] = { (void *) gsl_sf_hyperg_0F1, (void *) gsl_sf_hyperg_0F1 };

/*Using sf_hyperg_1F1_int_e as pyton name*/
static void * sf_hyperg_1F1_int_e_data [] = { (void *) gsl_sf_hyperg_1F1_int_e, (void *) gsl_sf_hyperg_1F1_int_e };

/*Using sf_hyperg_1F1_int as pyton name*/
static void * sf_hyperg_1F1_int_data [] = { (void *) gsl_sf_hyperg_1F1_int, (void *) gsl_sf_hyperg_1F1_int };

/*Using sf_hyperg_1F1_e as pyton name*/
static void * sf_hyperg_1F1_e_data [] = { (void *) gsl_sf_hyperg_1F1_e, (void *) gsl_sf_hyperg_1F1_e };

/*Using sf_hyperg_1F1 as pyton name*/
static void * sf_hyperg_1F1_data [] = { (void *) gsl_sf_hyperg_1F1, (void *) gsl_sf_hyperg_1F1 };

/*Using sf_hyperg_U_int_e as pyton name*/
static void * sf_hyperg_U_int_e_data [] = { (void *) gsl_sf_hyperg_U_int_e, (void *) gsl_sf_hyperg_U_int_e };

/*Using sf_hyperg_U_int as pyton name*/
static void * sf_hyperg_U_int_data [] = { (void *) gsl_sf_hyperg_U_int, (void *) gsl_sf_hyperg_U_int };

/*Using sf_hyperg_U_int_e10_e as pyton name*/
static void * sf_hyperg_U_int_e10_e_data [] = { (void *) gsl_sf_hyperg_U_int_e10_e, (void *) gsl_sf_hyperg_U_int_e10_e };

/*Using sf_hyperg_U_e as pyton name*/
static void * sf_hyperg_U_e_data [] = { (void *) gsl_sf_hyperg_U_e, (void *) gsl_sf_hyperg_U_e };

/*Using sf_hyperg_U as pyton name*/
static void * sf_hyperg_U_data [] = { (void *) gsl_sf_hyperg_U, (void *) gsl_sf_hyperg_U };

/*Using sf_hyperg_U_e10_e as pyton name*/
static void * sf_hyperg_U_e10_e_data [] = { (void *) gsl_sf_hyperg_U_e10_e, (void *) gsl_sf_hyperg_U_e10_e };

/*Using sf_hyperg_2F1_e as pyton name*/
static void * sf_hyperg_2F1_e_data [] = { (void *) gsl_sf_hyperg_2F1_e, (void *) gsl_sf_hyperg_2F1_e };

/*Using sf_hyperg_2F1 as pyton name*/
static void * sf_hyperg_2F1_data [] = { (void *) gsl_sf_hyperg_2F1, (void *) gsl_sf_hyperg_2F1 };

/*Using sf_hyperg_2F1_conj_e as pyton name*/
static void * sf_hyperg_2F1_conj_e_data [] = { (void *) gsl_sf_hyperg_2F1_conj_e, (void *) gsl_sf_hyperg_2F1_conj_e };

/*Using sf_hyperg_2F1_conj as pyton name*/
static void * sf_hyperg_2F1_conj_data [] = { (void *) gsl_sf_hyperg_2F1_conj, (void *) gsl_sf_hyperg_2F1_conj };

/*Using sf_hyperg_2F1_renorm_e as pyton name*/
static void * sf_hyperg_2F1_renorm_e_data [] = { (void *) gsl_sf_hyperg_2F1_renorm_e, (void *) gsl_sf_hyperg_2F1_renorm_e };

/*Using sf_hyperg_2F1_renorm as pyton name*/
static void * sf_hyperg_2F1_renorm_data [] = { (void *) gsl_sf_hyperg_2F1_renorm, (void *) gsl_sf_hyperg_2F1_renorm };

/*Using sf_hyperg_2F1_conj_renorm_e as pyton name*/
static void * sf_hyperg_2F1_conj_renorm_e_data [] = { (void *) gsl_sf_hyperg_2F1_conj_renorm_e, (void *) gsl_sf_hyperg_2F1_conj_renorm_e };

/*Using sf_hyperg_2F1_conj_renorm as pyton name*/
static void * sf_hyperg_2F1_conj_renorm_data [] = { (void *) gsl_sf_hyperg_2F1_conj_renorm, (void *) gsl_sf_hyperg_2F1_conj_renorm };

/*Using sf_hyperg_2F0_e as pyton name*/
static void * sf_hyperg_2F0_e_data [] = { (void *) gsl_sf_hyperg_2F0_e, (void *) gsl_sf_hyperg_2F0_e };

/*Using sf_hyperg_2F0 as pyton name*/
static void * sf_hyperg_2F0_data [] = { (void *) gsl_sf_hyperg_2F0, (void *) gsl_sf_hyperg_2F0 };

/*Using sf_laguerre_1_e as pyton name*/
static void * sf_laguerre_1_e_data [] = { (void *) gsl_sf_laguerre_1_e, (void *) gsl_sf_laguerre_1_e };

/*Using sf_laguerre_2_e as pyton name*/
static void * sf_laguerre_2_e_data [] = { (void *) gsl_sf_laguerre_2_e, (void *) gsl_sf_laguerre_2_e };

/*Using sf_laguerre_3_e as pyton name*/
static void * sf_laguerre_3_e_data [] = { (void *) gsl_sf_laguerre_3_e, (void *) gsl_sf_laguerre_3_e };

/*Using sf_laguerre_1 as pyton name*/
static void * sf_laguerre_1_data [] = { (void *) gsl_sf_laguerre_1, (void *) gsl_sf_laguerre_1 };

/*Using sf_laguerre_2 as pyton name*/
static void * sf_laguerre_2_data [] = { (void *) gsl_sf_laguerre_2, (void *) gsl_sf_laguerre_2 };

/*Using sf_laguerre_3 as pyton name*/
static void * sf_laguerre_3_data [] = { (void *) gsl_sf_laguerre_3, (void *) gsl_sf_laguerre_3 };

/*Using sf_laguerre_n_e as pyton name*/
static void * sf_laguerre_n_e_data [] = { (void *) gsl_sf_laguerre_n_e, (void *) gsl_sf_laguerre_n_e };

/*Using sf_laguerre_n as pyton name*/
static void * sf_laguerre_n_data [] = { (void *) gsl_sf_laguerre_n, (void *) gsl_sf_laguerre_n };

/*Using sf_lambert_W0_e as pyton name*/
static void * sf_lambert_W0_e_data [] = { (void *) gsl_sf_lambert_W0_e, (void *) gsl_sf_lambert_W0_e };

/*Using sf_lambert_W0 as pyton name*/
static void * sf_lambert_W0_data [] = { (void *) gsl_sf_lambert_W0, (void *) gsl_sf_lambert_W0 };

/*Using sf_lambert_Wm1_e as pyton name*/
static void * sf_lambert_Wm1_e_data [] = { (void *) gsl_sf_lambert_Wm1_e, (void *) gsl_sf_lambert_Wm1_e };

/*Using sf_lambert_Wm1 as pyton name*/
static void * sf_lambert_Wm1_data [] = { (void *) gsl_sf_lambert_Wm1, (void *) gsl_sf_lambert_Wm1 };

/*Using sf_legendre_Pl_e as pyton name*/
static void * sf_legendre_Pl_e_data [] = { (void *) gsl_sf_legendre_Pl_e, (void *) gsl_sf_legendre_Pl_e };

/*Using sf_legendre_Pl as pyton name*/
static void * sf_legendre_Pl_data [] = { (void *) gsl_sf_legendre_Pl, (void *) gsl_sf_legendre_Pl };

/*Using sf_legendre_P1_e as pyton name*/
static void * sf_legendre_P1_e_data [] = { (void *) gsl_sf_legendre_P1_e, (void *) gsl_sf_legendre_P1_e };

/*Using sf_legendre_P2_e as pyton name*/
static void * sf_legendre_P2_e_data [] = { (void *) gsl_sf_legendre_P2_e, (void *) gsl_sf_legendre_P2_e };

/*Using sf_legendre_P3_e as pyton name*/
static void * sf_legendre_P3_e_data [] = { (void *) gsl_sf_legendre_P3_e, (void *) gsl_sf_legendre_P3_e };

/*Using sf_legendre_P1 as pyton name*/
static void * sf_legendre_P1_data [] = { (void *) gsl_sf_legendre_P1, (void *) gsl_sf_legendre_P1 };

/*Using sf_legendre_P2 as pyton name*/
static void * sf_legendre_P2_data [] = { (void *) gsl_sf_legendre_P2, (void *) gsl_sf_legendre_P2 };

/*Using sf_legendre_P3 as pyton name*/
static void * sf_legendre_P3_data [] = { (void *) gsl_sf_legendre_P3, (void *) gsl_sf_legendre_P3 };

/*Using sf_legendre_Q0_e as pyton name*/
static void * sf_legendre_Q0_e_data [] = { (void *) gsl_sf_legendre_Q0_e, (void *) gsl_sf_legendre_Q0_e };

/*Using sf_legendre_Q0 as pyton name*/
static void * sf_legendre_Q0_data [] = { (void *) gsl_sf_legendre_Q0, (void *) gsl_sf_legendre_Q0 };

/*Using sf_legendre_Q1_e as pyton name*/
static void * sf_legendre_Q1_e_data [] = { (void *) gsl_sf_legendre_Q1_e, (void *) gsl_sf_legendre_Q1_e };

/*Using sf_legendre_Q1 as pyton name*/
static void * sf_legendre_Q1_data [] = { (void *) gsl_sf_legendre_Q1, (void *) gsl_sf_legendre_Q1 };

/*Using sf_legendre_Ql_e as pyton name*/
static void * sf_legendre_Ql_e_data [] = { (void *) gsl_sf_legendre_Ql_e, (void *) gsl_sf_legendre_Ql_e };

/*Using sf_legendre_Ql as pyton name*/
static void * sf_legendre_Ql_data [] = { (void *) gsl_sf_legendre_Ql, (void *) gsl_sf_legendre_Ql };

/*Using sf_legendre_Plm_e as pyton name*/
static void * sf_legendre_Plm_e_data [] = { (void *) gsl_sf_legendre_Plm_e, (void *) gsl_sf_legendre_Plm_e };

/*Using sf_legendre_Plm as pyton name*/
static void * sf_legendre_Plm_data [] = { (void *) gsl_sf_legendre_Plm, (void *) gsl_sf_legendre_Plm };

/*Using sf_legendre_sphPlm_e as pyton name*/
static void * sf_legendre_sphPlm_e_data [] = { (void *) gsl_sf_legendre_sphPlm_e, (void *) gsl_sf_legendre_sphPlm_e };

/*Using sf_legendre_sphPlm as pyton name*/
static void * sf_legendre_sphPlm_data [] = { (void *) gsl_sf_legendre_sphPlm, (void *) gsl_sf_legendre_sphPlm };

/*Using sf_conicalP_half_e as pyton name*/
static void * sf_conicalP_half_e_data [] = { (void *) gsl_sf_conicalP_half_e, (void *) gsl_sf_conicalP_half_e };

/*Using sf_conicalP_half as pyton name*/
static void * sf_conicalP_half_data [] = { (void *) gsl_sf_conicalP_half, (void *) gsl_sf_conicalP_half };

/*Using sf_conicalP_mhalf_e as pyton name*/
static void * sf_conicalP_mhalf_e_data [] = { (void *) gsl_sf_conicalP_mhalf_e, (void *) gsl_sf_conicalP_mhalf_e };

/*Using sf_conicalP_mhalf as pyton name*/
static void * sf_conicalP_mhalf_data [] = { (void *) gsl_sf_conicalP_mhalf, (void *) gsl_sf_conicalP_mhalf };

/*Using sf_conicalP_0_e as pyton name*/
static void * sf_conicalP_0_e_data [] = { (void *) gsl_sf_conicalP_0_e, (void *) gsl_sf_conicalP_0_e };

/*Using sf_conicalP_0 as pyton name*/
static void * sf_conicalP_0_data [] = { (void *) gsl_sf_conicalP_0, (void *) gsl_sf_conicalP_0 };

/*Using sf_conicalP_1_e as pyton name*/
static void * sf_conicalP_1_e_data [] = { (void *) gsl_sf_conicalP_1_e, (void *) gsl_sf_conicalP_1_e };

/*Using sf_conicalP_1 as pyton name*/
static void * sf_conicalP_1_data [] = { (void *) gsl_sf_conicalP_1, (void *) gsl_sf_conicalP_1 };

/*Using sf_conicalP_sph_reg_e as pyton name*/
static void * sf_conicalP_sph_reg_e_data [] = { (void *) gsl_sf_conicalP_sph_reg_e, (void *) gsl_sf_conicalP_sph_reg_e };

/*Using sf_conicalP_sph_reg as pyton name*/
static void * sf_conicalP_sph_reg_data [] = { (void *) gsl_sf_conicalP_sph_reg, (void *) gsl_sf_conicalP_sph_reg };

/*Using sf_conicalP_cyl_reg_e as pyton name*/
static void * sf_conicalP_cyl_reg_e_data [] = { (void *) gsl_sf_conicalP_cyl_reg_e, (void *) gsl_sf_conicalP_cyl_reg_e };

/*Using sf_conicalP_cyl_reg as pyton name*/
static void * sf_conicalP_cyl_reg_data [] = { (void *) gsl_sf_conicalP_cyl_reg, (void *) gsl_sf_conicalP_cyl_reg };

/*Using sf_legendre_H3d_0_e as pyton name*/
static void * sf_legendre_H3d_0_e_data [] = { (void *) gsl_sf_legendre_H3d_0_e, (void *) gsl_sf_legendre_H3d_0_e };

/*Using sf_legendre_H3d_0 as pyton name*/
static void * sf_legendre_H3d_0_data [] = { (void *) gsl_sf_legendre_H3d_0, (void *) gsl_sf_legendre_H3d_0 };

/*Using sf_legendre_H3d_1_e as pyton name*/
static void * sf_legendre_H3d_1_e_data [] = { (void *) gsl_sf_legendre_H3d_1_e, (void *) gsl_sf_legendre_H3d_1_e };

/*Using sf_legendre_H3d_1 as pyton name*/
static void * sf_legendre_H3d_1_data [] = { (void *) gsl_sf_legendre_H3d_1, (void *) gsl_sf_legendre_H3d_1 };

/*Using sf_legendre_H3d_e as pyton name*/
static void * sf_legendre_H3d_e_data [] = { (void *) gsl_sf_legendre_H3d_e, (void *) gsl_sf_legendre_H3d_e };

/*Using sf_legendre_H3d as pyton name*/
static void * sf_legendre_H3d_data [] = { (void *) gsl_sf_legendre_H3d, (void *) gsl_sf_legendre_H3d };

/*Using sf_log_e as pyton name*/
static void * sf_log_e_data [] = { (void *) gsl_sf_log_e, (void *) gsl_sf_log_e };

/*Using sf_log as pyton name*/
static void * sf_log_data [] = { (void *) gsl_sf_log, (void *) gsl_sf_log };

/*Using sf_log_abs_e as pyton name*/
static void * sf_log_abs_e_data [] = { (void *) gsl_sf_log_abs_e, (void *) gsl_sf_log_abs_e };

/*Using sf_log_abs as pyton name*/
static void * sf_log_abs_data [] = { (void *) gsl_sf_log_abs, (void *) gsl_sf_log_abs };

/*Using sf_log_1plusx_e as pyton name*/
static void * sf_log_1plusx_e_data [] = { (void *) gsl_sf_log_1plusx_e, (void *) gsl_sf_log_1plusx_e };

/*Using sf_log_1plusx as pyton name*/
static void * sf_log_1plusx_data [] = { (void *) gsl_sf_log_1plusx, (void *) gsl_sf_log_1plusx };

/*Using sf_log_1plusx_mx_e as pyton name*/
static void * sf_log_1plusx_mx_e_data [] = { (void *) gsl_sf_log_1plusx_mx_e, (void *) gsl_sf_log_1plusx_mx_e };

/*Using sf_log_1plusx_mx as pyton name*/
static void * sf_log_1plusx_mx_data [] = { (void *) gsl_sf_log_1plusx_mx, (void *) gsl_sf_log_1plusx_mx };

/*Using sf_mathieu_a as pyton name*/
static void * sf_mathieu_a_data [] = { (void *) gsl_sf_mathieu_a, (void *) gsl_sf_mathieu_a };

/*Using sf_mathieu_b as pyton name*/
static void * sf_mathieu_b_data [] = { (void *) gsl_sf_mathieu_b, (void *) gsl_sf_mathieu_b };

/*Using sf_mathieu_a_coeff as pyton name*/
static void * sf_mathieu_a_coeff_data [] = { (void *) gsl_sf_mathieu_a_coeff, (void *) gsl_sf_mathieu_a_coeff };

/*Using sf_mathieu_b_coeff as pyton name*/
static void * sf_mathieu_b_coeff_data [] = { (void *) gsl_sf_mathieu_b_coeff, (void *) gsl_sf_mathieu_b_coeff };

/*Using sf_mathieu_se as pyton name*/
static void * sf_mathieu_se_data [] = { (void *) gsl_sf_mathieu_se, (void *) gsl_sf_mathieu_se };

/*Using sf_mathieu_Mc as pyton name*/
static void * sf_mathieu_Mc_data [] = { (void *) gsl_sf_mathieu_Mc, (void *) gsl_sf_mathieu_Mc };

/*Using sf_mathieu_Ms as pyton name*/
static void * sf_mathieu_Ms_data [] = { (void *) gsl_sf_mathieu_Ms, (void *) gsl_sf_mathieu_Ms };

/*Using sf_pow_int_e as pyton name*/
static void * sf_pow_int_e_data [] = { (void *) gsl_sf_pow_int_e, (void *) gsl_sf_pow_int_e };

/*Using sf_pow_int as pyton name*/
static void * sf_pow_int_data [] = { (void *) gsl_sf_pow_int, (void *) gsl_sf_pow_int };

/*Using sf_psi_int_e as pyton name*/
static void * sf_psi_int_e_data [] = { (void *) gsl_sf_psi_int_e, (void *) gsl_sf_psi_int_e };

/*Using sf_psi_int as pyton name*/
static void * sf_psi_int_data [] = { (void *) gsl_sf_psi_int, (void *) gsl_sf_psi_int };

/*Using sf_psi_e as pyton name*/
static void * sf_psi_e_data [] = { (void *) gsl_sf_psi_e, (void *) gsl_sf_psi_e };

/*Using sf_psi as pyton name*/
static void * sf_psi_data [] = { (void *) gsl_sf_psi, (void *) gsl_sf_psi };

/*Using sf_psi_1piy_e as pyton name*/
static void * sf_psi_1piy_e_data [] = { (void *) gsl_sf_psi_1piy_e, (void *) gsl_sf_psi_1piy_e };

/*Using sf_psi_1piy as pyton name*/
static void * sf_psi_1piy_data [] = { (void *) gsl_sf_psi_1piy, (void *) gsl_sf_psi_1piy };

/*Using sf_complex_psi_e as pyton name*/
static void * sf_complex_psi_e_data [] = { (void *) gsl_sf_complex_psi_e, (void *) gsl_sf_complex_psi_e };

/*Using sf_psi_1_int_e as pyton name*/
static void * sf_psi_1_int_e_data [] = { (void *) gsl_sf_psi_1_int_e, (void *) gsl_sf_psi_1_int_e };

/*Using sf_psi_1_int as pyton name*/
static void * sf_psi_1_int_data [] = { (void *) gsl_sf_psi_1_int, (void *) gsl_sf_psi_1_int };

/*Using sf_psi_1_e as pyton name*/
static void * sf_psi_1_e_data [] = { (void *) gsl_sf_psi_1_e, (void *) gsl_sf_psi_1_e };

/*Using sf_psi_1 as pyton name*/
static void * sf_psi_1_data [] = { (void *) gsl_sf_psi_1, (void *) gsl_sf_psi_1 };

/*Using sf_psi_n_e as pyton name*/
static void * sf_psi_n_e_data [] = { (void *) gsl_sf_psi_n_e, (void *) gsl_sf_psi_n_e };

/*Using sf_psi_n as pyton name*/
static void * sf_psi_n_data [] = { (void *) gsl_sf_psi_n, (void *) gsl_sf_psi_n };

/*Using sf_synchrotron_1_e as pyton name*/
static void * sf_synchrotron_1_e_data [] = { (void *) gsl_sf_synchrotron_1_e, (void *) gsl_sf_synchrotron_1_e };

/*Using sf_synchrotron_1 as pyton name*/
static void * sf_synchrotron_1_data [] = { (void *) gsl_sf_synchrotron_1, (void *) gsl_sf_synchrotron_1 };

/*Using sf_synchrotron_2_e as pyton name*/
static void * sf_synchrotron_2_e_data [] = { (void *) gsl_sf_synchrotron_2_e, (void *) gsl_sf_synchrotron_2_e };

/*Using sf_synchrotron_2 as pyton name*/
static void * sf_synchrotron_2_data [] = { (void *) gsl_sf_synchrotron_2, (void *) gsl_sf_synchrotron_2 };

/*Using sf_transport_2_e as pyton name*/
static void * sf_transport_2_e_data [] = { (void *) gsl_sf_transport_2_e, (void *) gsl_sf_transport_2_e };

/*Using sf_transport_2 as pyton name*/
static void * sf_transport_2_data [] = { (void *) gsl_sf_transport_2, (void *) gsl_sf_transport_2 };

/*Using sf_transport_3_e as pyton name*/
static void * sf_transport_3_e_data [] = { (void *) gsl_sf_transport_3_e, (void *) gsl_sf_transport_3_e };

/*Using sf_transport_3 as pyton name*/
static void * sf_transport_3_data [] = { (void *) gsl_sf_transport_3, (void *) gsl_sf_transport_3 };

/*Using sf_transport_4_e as pyton name*/
static void * sf_transport_4_e_data [] = { (void *) gsl_sf_transport_4_e, (void *) gsl_sf_transport_4_e };

/*Using sf_transport_4 as pyton name*/
static void * sf_transport_4_data [] = { (void *) gsl_sf_transport_4, (void *) gsl_sf_transport_4 };

/*Using sf_transport_5_e as pyton name*/
static void * sf_transport_5_e_data [] = { (void *) gsl_sf_transport_5_e, (void *) gsl_sf_transport_5_e };

/*Using sf_transport_5 as pyton name*/
static void * sf_transport_5_data [] = { (void *) gsl_sf_transport_5, (void *) gsl_sf_transport_5 };

/*Using sf_sin_e as pyton name*/
static void * sf_sin_e_data [] = { (void *) gsl_sf_sin_e, (void *) gsl_sf_sin_e };

/*Using sf_sin as pyton name*/
static void * sf_sin_data [] = { (void *) gsl_sf_sin, (void *) gsl_sf_sin };

/*Using sf_cos_e as pyton name*/
static void * sf_cos_e_data [] = { (void *) gsl_sf_cos_e, (void *) gsl_sf_cos_e };

/*Using sf_cos as pyton name*/
static void * sf_cos_data [] = { (void *) gsl_sf_cos, (void *) gsl_sf_cos };

/*Using sf_hypot_e as pyton name*/
static void * sf_hypot_e_data [] = { (void *) gsl_sf_hypot_e, (void *) gsl_sf_hypot_e };

/*Using sf_hypot as pyton name*/
static void * sf_hypot_data [] = { (void *) gsl_sf_hypot, (void *) gsl_sf_hypot };

/*Using sf_sinc_e as pyton name*/
static void * sf_sinc_e_data [] = { (void *) gsl_sf_sinc_e, (void *) gsl_sf_sinc_e };

/*Using sf_sinc as pyton name*/
static void * sf_sinc_data [] = { (void *) gsl_sf_sinc, (void *) gsl_sf_sinc };

/*Using sf_lnsinh_e as pyton name*/
static void * sf_lnsinh_e_data [] = { (void *) gsl_sf_lnsinh_e, (void *) gsl_sf_lnsinh_e };

/*Using sf_lnsinh as pyton name*/
static void * sf_lnsinh_data [] = { (void *) gsl_sf_lnsinh, (void *) gsl_sf_lnsinh };

/*Using sf_lncosh_e as pyton name*/
static void * sf_lncosh_e_data [] = { (void *) gsl_sf_lncosh_e, (void *) gsl_sf_lncosh_e };

/*Using sf_lncosh as pyton name*/
static void * sf_lncosh_data [] = { (void *) gsl_sf_lncosh, (void *) gsl_sf_lncosh };

/*Using sf_sin_err_e as pyton name*/
static void * sf_sin_err_e_data [] = { (void *) gsl_sf_sin_err_e, (void *) gsl_sf_sin_err_e };

/*Using sf_cos_err_e as pyton name*/
static void * sf_cos_err_e_data [] = { (void *) gsl_sf_cos_err_e, (void *) gsl_sf_cos_err_e };

/*Using sf_angle_restrict_symm as pyton name*/
static void * sf_angle_restrict_symm_data [] = { (void *) gsl_sf_angle_restrict_symm, (void *) gsl_sf_angle_restrict_symm };

/*Using sf_angle_restrict_pos as pyton name*/
static void * sf_angle_restrict_pos_data [] = { (void *) gsl_sf_angle_restrict_pos, (void *) gsl_sf_angle_restrict_pos };

/*Using sf_angle_restrict_symm_err_e as pyton name*/
static void * sf_angle_restrict_symm_err_e_data [] = { (void *) gsl_sf_angle_restrict_symm_err_e, (void *) gsl_sf_angle_restrict_symm_err_e };

/*Using sf_angle_restrict_pos_err_e as pyton name*/
static void * sf_angle_restrict_pos_err_e_data [] = { (void *) gsl_sf_angle_restrict_pos_err_e, (void *) gsl_sf_angle_restrict_pos_err_e };

/*Using sf_zeta_int_e as pyton name*/
static void * sf_zeta_int_e_data [] = { (void *) gsl_sf_zeta_int_e, (void *) gsl_sf_zeta_int_e };

/*Using sf_zeta_int as pyton name*/
static void * sf_zeta_int_data [] = { (void *) gsl_sf_zeta_int, (void *) gsl_sf_zeta_int };

/*Using sf_zeta_e as pyton name*/
static void * sf_zeta_e_data [] = { (void *) gsl_sf_zeta_e, (void *) gsl_sf_zeta_e };

/*Using sf_zeta as pyton name*/
static void * sf_zeta_data [] = { (void *) gsl_sf_zeta, (void *) gsl_sf_zeta };

/*Using sf_zetam1_e as pyton name*/
static void * sf_zetam1_e_data [] = { (void *) gsl_sf_zetam1_e, (void *) gsl_sf_zetam1_e };

/*Using sf_zetam1 as pyton name*/
static void * sf_zetam1_data [] = { (void *) gsl_sf_zetam1, (void *) gsl_sf_zetam1 };

/*Using sf_zetam1_int_e as pyton name*/
static void * sf_zetam1_int_e_data [] = { (void *) gsl_sf_zetam1_int_e, (void *) gsl_sf_zetam1_int_e };

/*Using sf_zetam1_int as pyton name*/
static void * sf_zetam1_int_data [] = { (void *) gsl_sf_zetam1_int, (void *) gsl_sf_zetam1_int };

/*Using sf_hzeta_e as pyton name*/
static void * sf_hzeta_e_data [] = { (void *) gsl_sf_hzeta_e, (void *) gsl_sf_hzeta_e };

/*Using sf_hzeta as pyton name*/
static void * sf_hzeta_data [] = { (void *) gsl_sf_hzeta, (void *) gsl_sf_hzeta };

/*Using sf_eta_int_e as pyton name*/
static void * sf_eta_int_e_data [] = { (void *) gsl_sf_eta_int_e, (void *) gsl_sf_eta_int_e };

/*Using sf_eta_int as pyton name*/
static void * sf_eta_int_data [] = { (void *) gsl_sf_eta_int, (void *) gsl_sf_eta_int };

/*Using sf_eta_e as pyton name*/
static void * sf_eta_e_data [] = { (void *) gsl_sf_eta_e, (void *) gsl_sf_eta_e };

/*Using sf_eta as pyton name*/
static void * sf_eta_data [] = { (void *) gsl_sf_eta, (void *) gsl_sf_eta };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pD_DD__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pD_DD__one_doc =
"\n"
"     2 input  args :  DD\n"
"     1 output args :  D \n";


static char PyGSL_sf_ufunc_pD_DD__one_types [] = { PyArray_CDOUBLE, PyArray_CDOUBLE, PyArray_CDOUBLE, 
                                                  PyArray_CDOUBLE, PyArray_CDOUBLE, PyArray_CDOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pD_D__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pD_D__one_doc =
"\n"
"     1 input  args :  D\n"
"     1 output args :  D \n";


static char PyGSL_sf_ufunc_pD_D__one_types [] = { PyArray_CDOUBLE, PyArray_CDOUBLE, 
                                                 PyArray_CDOUBLE, PyArray_CDOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pD_Dd__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pD_Dd__one_doc =
"\n"
"     2 input  args :  Dd\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pD_Dd__one_types [] = { PyArray_CDOUBLE, PyArray_FLOAT, PyArray_CDOUBLE, 
                                                  PyArray_CDOUBLE, PyArray_DOUBLE, PyArray_CDOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pD_d__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pD_d__one_doc =
"\n"
"     1 input  args :  d\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pD_d__one_types [] = { PyArray_FLOAT, PyArray_CDOUBLE, 
                                                 PyArray_DOUBLE, PyArray_CDOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pD_dd__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pD_dd__one_doc =
"\n"
"     2 input  args :  dd\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pD_dd__one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_CDOUBLE, 
                                                  PyArray_DOUBLE, PyArray_DOUBLE, PyArray_CDOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_D__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_D__one_doc =
"\n"
"     1 input  args :  D\n"
"     1 output args :  D \n";


static char PyGSL_sf_ufunc_pd_D__one_types [] = { PyArray_CDOUBLE, PyArray_FLOAT, 
                                                 PyArray_CDOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_d__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_d__one_doc =
"\n"
"     1 input  args :  d\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pd_d__one_types [] = { PyArray_FLOAT, PyArray_FLOAT, 
                                                 PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_dd__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_dd__one_doc =
"\n"
"     2 input  args :  dd\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pd_dd__one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                  PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_ddd__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_ddd__one_doc =
"\n"
"     3 input  args :  ddd\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pd_ddd__one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                   PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_dddd__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_dddd__one_doc =
"\n"
"     4 input  args :  dddd\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pd_dddd__one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                    PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_ddddm__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_ddddm__one_doc =
"\n"
"     5 input  args :  ddddm\n"
"     1 output args :  m "
"\n\n"
" Argument 5 is a gsl_mode_t, valid parameters are:\n	sf.PREC_DOUBLE or sf.PREC_SINGLE or sf.PREC_APPROX\n"
"\n";


static char PyGSL_sf_ufunc_pd_ddddm__one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, 
                                                     PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_dddm__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_dddm__one_doc =
"\n"
"     4 input  args :  dddm\n"
"     1 output args :  m "
"\n\n"
" Argument 4 is a gsl_mode_t, valid parameters are:\n	sf.PREC_DOUBLE or sf.PREC_SINGLE or sf.PREC_APPROX\n"
"\n";


static char PyGSL_sf_ufunc_pd_dddm__one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, 
                                                    PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_ddm__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_ddm__one_doc =
"\n"
"     3 input  args :  ddm\n"
"     1 output args :  m "
"\n\n"
" Argument 3 is a gsl_mode_t, valid parameters are:\n	sf.PREC_DOUBLE or sf.PREC_SINGLE or sf.PREC_APPROX\n"
"\n";


static char PyGSL_sf_ufunc_pd_ddm__one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, 
                                                   PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_di__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_di__one_doc =
"\n"
"     2 input  args :  di\n"
"     1 output args :  i \n";


static char PyGSL_sf_ufunc_pd_di__one_types [] = { PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, 
                                                  PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_dm__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_dm__one_doc =
"\n"
"     2 input  args :  dm\n"
"     1 output args :  m "
"\n\n"
" Argument 2 is a gsl_mode_t, valid parameters are:\n	sf.PREC_DOUBLE or sf.PREC_SINGLE or sf.PREC_APPROX\n"
"\n";


static char PyGSL_sf_ufunc_pd_dm__one_types [] = { PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, 
                                                  PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_dui__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_dui__one_doc =
"\n"
"     2 input  args :  dui\n"
"     1 output args :  ui \n";


static char PyGSL_sf_ufunc_pd_dui__one_types [] = { PyArray_FLOAT, PyArray_UINT, PyArray_FLOAT, 
                                                   PyArray_DOUBLE, PyArray_UINT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_i__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_i__one_doc =
"\n"
"     1 input  args :  i\n"
"     1 output args :  i \n";


static char PyGSL_sf_ufunc_pd_i__one_types [] = { PyArray_INT, PyArray_FLOAT, 
                                                 PyArray_INT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_id__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_id__one_doc =
"\n"
"     2 input  args :  id\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pd_id__one_types [] = { PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                  PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_idd__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_idd__one_doc =
"\n"
"     3 input  args :  idd\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pd_idd__one_types [] = { PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                   PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_iid__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_iid__one_doc =
"\n"
"     3 input  args :  iid\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pd_iid__one_types [] = { PyArray_INT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                   PyArray_INT, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_iidd__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_iidd__one_doc =
"\n"
"     4 input  args :  iidd\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pd_iidd__one_types [] = { PyArray_INT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                    PyArray_INT, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_iiiiii__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_iiiiii__one_doc =
"\n"
"     6 input  args :  iiiiii\n"
"     1 output args :  i \n";


static char PyGSL_sf_ufunc_pd_iiiiii__one_types [] = { PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_FLOAT, 
                                                      PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_iiiiiiiii__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_iiiiiiiii__one_doc =
"\n"
"     9 input  args :  iiiiiiiii\n"
"     1 output args :  i \n";


static char PyGSL_sf_ufunc_pd_iiiiiiiii__one_types [] = { PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_FLOAT, 
                                                         PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_ui__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_ui__one_doc =
"\n"
"     1 input  args :  ui\n"
"     1 output args :  ui \n";


static char PyGSL_sf_ufunc_pd_ui__one_types [] = { PyArray_UINT, PyArray_FLOAT, 
                                                  PyArray_UINT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pd_uiui__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pd_uiui__one_doc =
"\n"
"     2 input  args :  uiui\n"
"     1 output args :  ui \n";


static char PyGSL_sf_ufunc_pd_uiui__one_types [] = { PyArray_UINT, PyArray_UINT, PyArray_FLOAT, 
                                                    PyArray_UINT, PyArray_UINT, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pi_id_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pi_id_rd_one_doc =
"\n"
"     2 input  args :  id\n"
"     3 output args :  drd "
"\n\n"
"Return Arguments 2 and 3 resemble a gsl_result argument,\n\twhich is  argument 3 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_pi_id_rd_one_types [] = { PyArray_INT, PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                    PyArray_INT, PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pi_idd_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pi_idd_rd_one_doc =
"\n"
"     3 input  args :  idd\n"
"     3 output args :  drd "
"\n\n"
"Return Arguments 2 and 3 resemble a gsl_result argument,\n\twhich is  argument 4 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_pi_idd_rd_one_types [] = { PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                     PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pi_iddd__one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pi_iddd__one_doc =
"\n"
"     4 input  args :  iddd\n"
"     1 output args :  d \n";


static char PyGSL_sf_ufunc_pi_iddd__one_types [] = { PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, 
                                                    PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT };

static PyUFuncGenericFunction PyGSL_sf_ufunc_pi_iidd_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_pi_iidd_rd_one_doc =
"\n"
"     4 input  args :  iidd\n"
"     3 output args :  drd "
"\n\n"
"Return Arguments 2 and 3 resemble a gsl_result argument,\n\twhich is  argument 5 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_pi_iidd_rd_one_types [] = { PyArray_INT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                      PyArray_INT, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_d_erd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_d_erd_one_doc =
"\n"
"     1 input  args :  d\n"
"     3 output args :  erd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 - 3 resemble a gsl_result_e10 argument,\n\twhich is argument 2 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_d_erd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, 
                                                    PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_d_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_d_rd_one_doc =
"\n"
"     1 input  args :  d\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 2 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_d_rd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                   PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_d_rdd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_d_rdd_one_doc =
"\n"
"     1 input  args :  d\n"
"     3 output args :  rdd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 2 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_d_rdd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                    PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dd_ddd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dd_ddd_one_doc =
"\n"
"     2 input  args :  dd\n"
"     3 output args :  ddd "
"\n\n"
"The error flag is discarded.\n"
"\n";


static char PyGSL_sf_ufunc_qi_dd_ddd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                     PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dd_erd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dd_erd_one_doc =
"\n"
"     2 input  args :  dd\n"
"     3 output args :  erd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 - 3 resemble a gsl_result_e10 argument,\n\twhich is argument 3 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_dd_erd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, 
                                                     PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dd_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dd_rd_one_doc =
"\n"
"     2 input  args :  dd\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 3 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_dd_rd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                    PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dd_rdd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dd_rdd_one_doc =
"\n"
"     2 input  args :  dd\n"
"     3 output args :  rdd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 3 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_dd_rdd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                     PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dd_rdrd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dd_rdrd_one_doc =
"\n"
"     2 input  args :  dd\n"
"     4 output args :  rdrd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 3 of the C argument list\n"
"Return Arguments 3 and 4 resemble a gsl_result argument,\n\twhich is  argument 4 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_dd_rdrd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                      PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_ddd_erd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_ddd_erd_one_doc =
"\n"
"     3 input  args :  ddd\n"
"     3 output args :  erd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 - 3 resemble a gsl_result_e10 argument,\n\twhich is argument 4 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_ddd_erd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, 
                                                      PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_ddd_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_ddd_rd_one_doc =
"\n"
"     3 input  args :  ddd\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 4 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_ddd_rd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                     PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dddd_erd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dddd_erd_one_doc =
"\n"
"     4 input  args :  dddd\n"
"     3 output args :  erd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 - 3 resemble a gsl_result_e10 argument,\n\twhich is argument 5 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_dddd_erd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, 
                                                       PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dddd_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dddd_rd_one_doc =
"\n"
"     4 input  args :  dddd\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 5 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_dddd_rd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                      PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_ddddm_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_ddddm_rd_one_doc =
"\n"
"     5 input  args :  ddddm\n"
"     2 output args :  rd "
"\n\n"
" Argument 5 is a gsl_mode_t, valid parameters are:\n	sf.PREC_DOUBLE or sf.PREC_SINGLE or sf.PREC_APPROX\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 6 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_ddddm_rd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                       PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dddi_rdrdrdrddd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dddi_rdrdrdrddd_one_doc =
"\n"
"     4 input  args :  dddi\n"
"    10 output args :  rdrdrdrddd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 5 of the C argument list\n"
"Return Arguments 3 and 4 resemble a gsl_result argument,\n\twhich is  argument 6 of the C argument list\n"
"Return Arguments 5 and 6 resemble a gsl_result argument,\n\twhich is  argument 7 of the C argument list\n"
"Return Arguments 7 and 8 resemble a gsl_result argument,\n\twhich is  argument 8 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_dddi_rdrdrdrddd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                              PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dddm_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dddm_rd_one_doc =
"\n"
"     4 input  args :  dddm\n"
"     2 output args :  rd "
"\n\n"
" Argument 4 is a gsl_mode_t, valid parameters are:\n	sf.PREC_DOUBLE or sf.PREC_SINGLE or sf.PREC_APPROX\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 5 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_dddm_rd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                      PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_ddm_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_ddm_rd_one_doc =
"\n"
"     3 input  args :  ddm\n"
"     2 output args :  rd "
"\n\n"
" Argument 3 is a gsl_mode_t, valid parameters are:\n	sf.PREC_DOUBLE or sf.PREC_SINGLE or sf.PREC_APPROX\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 4 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_ddm_rd_one_types [] = { PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                     PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_di_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_di_rd_one_doc =
"\n"
"     2 input  args :  di\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 3 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_di_rd_one_types [] = { PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                    PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dm_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dm_rd_one_doc =
"\n"
"     2 input  args :  dm\n"
"     2 output args :  rd "
"\n\n"
" Argument 2 is a gsl_mode_t, valid parameters are:\n	sf.PREC_DOUBLE or sf.PREC_SINGLE or sf.PREC_APPROX\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 3 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_dm_rd_one_types [] = { PyArray_FLOAT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                    PyArray_DOUBLE, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_dui_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_dui_rd_one_doc =
"\n"
"     2 input  args :  dui\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 3 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_dui_rd_one_types [] = { PyArray_FLOAT, PyArray_UINT, PyArray_FLOAT, PyArray_FLOAT, 
                                                     PyArray_DOUBLE, PyArray_UINT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_i_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_i_rd_one_doc =
"\n"
"     1 input  args :  i\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 2 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_i_rd_one_types [] = { PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                   PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_id_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_id_rd_one_doc =
"\n"
"     2 input  args :  id\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 3 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_id_rd_one_types [] = { PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                    PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_idd_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_idd_rd_one_doc =
"\n"
"     3 input  args :  idd\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 4 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_idd_rd_one_types [] = { PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                     PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_iid_erd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_iid_erd_one_doc =
"\n"
"     3 input  args :  iid\n"
"     3 output args :  erd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 - 3 resemble a gsl_result_e10 argument,\n\twhich is argument 4 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_iid_erd_one_types [] = { PyArray_INT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_INT, 
                                                      PyArray_INT, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_INT };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_iid_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_iid_rd_one_doc =
"\n"
"     3 input  args :  iid\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 4 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_iid_rd_one_types [] = { PyArray_INT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                     PyArray_INT, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_iidd_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_iidd_rd_one_doc =
"\n"
"     4 input  args :  iidd\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 5 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_iidd_rd_one_types [] = { PyArray_INT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, PyArray_FLOAT, 
                                                      PyArray_INT, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_iiiiii_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_iiiiii_rd_one_doc =
"\n"
"     6 input  args :  iiiiii\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 7 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_iiiiii_rd_one_types [] = { PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                        PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_iiiiiiiii_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_iiiiiiiii_rd_one_doc =
"\n"
"     9 input  args :  iiiiiiiii\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 10 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_iiiiiiiii_rd_one_types [] = { PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_FLOAT, PyArray_FLOAT, 
                                                           PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_INT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_ui_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_ui_rd_one_doc =
"\n"
"     1 input  args :  ui\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 2 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_ui_rd_one_types [] = { PyArray_UINT, PyArray_FLOAT, PyArray_FLOAT, 
                                                    PyArray_UINT, PyArray_DOUBLE, PyArray_DOUBLE };

static PyUFuncGenericFunction PyGSL_sf_ufunc_qi_uiui_rd_one_data[] = {NULL, NULL};


static  char * PyGSL_sf_ufunc_qi_uiui_rd_one_doc =
"\n"
"     2 input  args :  uiui\n"
"     2 output args :  rd "
"\n\n"
"The error flag is discarded.\n"
"Return Arguments 1 and 2 resemble a gsl_result argument,\n\twhich is  argument 3 of the C argument list\n"
"\n";


static char PyGSL_sf_ufunc_qi_uiui_rd_one_types [] = { PyArray_UINT, PyArray_UINT, PyArray_FLOAT, PyArray_FLOAT, 
                                                      PyArray_UINT, PyArray_UINT, PyArray_DOUBLE, PyArray_DOUBLE };

