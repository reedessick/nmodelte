"""
Here you find either new implemented modules or alternate implementations 
of already modules. This directory is intended to have a second implementation
beside the main implementation to have a discussion which implementation to 
favor on the long run.
"""
