/* -*- C -*- */
/* Automatically generated file
 * Do not edit directly.
 * Edit c.py instead!!!
 */
         
#define BASIS_gsl_vector_complex_long_double             gsl_vector_complex_long_double
#define BASIS_gsl_vector_complex_double                  gsl_vector_complex_double
#define BASIS_gsl_vector_complex_float                   gsl_vector_complex_float
#define BASIS_gsl_vector_complex                         gsl_vector_complex
#define BASIS_gsl_vector_long_double                     gsl_vector_long_double
#define BASIS_gsl_vector_double                          gsl_vector_double
#define BASIS_gsl_vector_float                           gsl_vector_float
#define BASIS_gsl_vector                                 gsl_vector
#define BASIS_gsl_vector_ulong                           gsl_vector_ulong
#define BASIS_gsl_vector_long                            gsl_vector_long
#define BASIS_gsl_vector_uint                            gsl_vector_uint
#define BASIS_gsl_vector_int                             gsl_vector_int
#define BASIS_gsl_vector_ushort                          gsl_vector_ushort
#define BASIS_gsl_vector_short                           gsl_vector_short
#define BASIS_gsl_vector_uchar                           gsl_vector_uchar
#define BASIS_gsl_vector_char                            gsl_vector_char

#define BASIS_gsl_vector_complex_long_double_view        gsl_vector_complex_long_double
#define BASIS_gsl_vector_complex_double_view             gsl_vector_complex_double
#define BASIS_gsl_vector_complex_float_view              gsl_vector_complex_float
#define BASIS_gsl_vector_complex_view                    gsl_vector_complex
#define BASIS_gsl_vector_long_double_view                gsl_vector_long_double
#define BASIS_gsl_vector_double_view                     gsl_vector_double
#define BASIS_gsl_vector_float_view                      gsl_vector_float
#define BASIS_gsl_vector_view                            gsl_vector
#define BASIS_gsl_vector_ulong_view                      gsl_vector_ulong
#define BASIS_gsl_vector_long_view                       gsl_vector_long
#define BASIS_gsl_vector_uint_view                       gsl_vector_uint
#define BASIS_gsl_vector_int_view                        gsl_vector_int
#define BASIS_gsl_vector_ushort_view                     gsl_vector_ushort
#define BASIS_gsl_vector_short_view                      gsl_vector_short
#define BASIS_gsl_vector_uchar_view                      gsl_vector_uchar
#define BASIS_gsl_vector_char_view                       gsl_vector_char


typedef gsl_complex_long_double             gsl_vector_complex_long_double_basis_type; 
typedef gsl_complex                         gsl_vector_complex_double_basis_type; 
typedef gsl_complex_float                   gsl_vector_complex_float_basis_type; 
typedef gsl_complex                         gsl_vector_complex_basis_type; 
typedef long double                         gsl_vector_long_double_basis_type; 
typedef double                              gsl_vector_double_basis_type; 
typedef float                               gsl_vector_float_basis_type; 
typedef double                              gsl_vector_basis_type; 
typedef unsigned long                       gsl_vector_ulong_basis_type; 
typedef long                                gsl_vector_long_basis_type; 
typedef unsigned int                        gsl_vector_uint_basis_type; 
typedef int                                 gsl_vector_int_basis_type; 
typedef unsigned short                      gsl_vector_ushort_basis_type; 
typedef short                               gsl_vector_short_basis_type; 
typedef unsigned char                       gsl_vector_uchar_basis_type; 
typedef char                                gsl_vector_char_basis_type; 

typedef gsl_complex_long_double             gsl_vector_complex_long_double_view_basis_type; 
typedef gsl_complex                         gsl_vector_complex_double_view_basis_type; 
typedef gsl_complex_float                   gsl_vector_complex_float_view_basis_type; 
typedef gsl_complex                         gsl_vector_complex_view_basis_type; 
typedef long double                         gsl_vector_long_double_view_basis_type; 
typedef double                              gsl_vector_double_view_basis_type; 
typedef float                               gsl_vector_float_view_basis_type; 
typedef double                              gsl_vector_view_basis_type; 
typedef unsigned long                       gsl_vector_ulong_view_basis_type; 
typedef long                                gsl_vector_long_view_basis_type; 
typedef unsigned int                        gsl_vector_uint_view_basis_type; 
typedef int                                 gsl_vector_int_view_basis_type; 
typedef unsigned short                      gsl_vector_ushort_view_basis_type; 
typedef short                               gsl_vector_short_view_basis_type; 
typedef unsigned char                       gsl_vector_uchar_view_basis_type; 
typedef char                                gsl_vector_char_view_basis_type; 


typedef long double                         gsl_vector_complex_long_double_basis_c_type; 
typedef double                              gsl_vector_complex_double_basis_c_type; 
typedef float                               gsl_vector_complex_float_basis_c_type; 
typedef double                              gsl_vector_complex_basis_c_type; 
typedef long double                         gsl_vector_long_double_basis_c_type; 
typedef double                              gsl_vector_double_basis_c_type; 
typedef float                               gsl_vector_float_basis_c_type; 
typedef double                              gsl_vector_basis_c_type; 
typedef unsigned long                       gsl_vector_ulong_basis_c_type; 
typedef long                                gsl_vector_long_basis_c_type; 
typedef unsigned int                        gsl_vector_uint_basis_c_type; 
typedef int                                 gsl_vector_int_basis_c_type; 
typedef unsigned short                      gsl_vector_ushort_basis_c_type; 
typedef short                               gsl_vector_short_basis_c_type; 
typedef unsigned char                       gsl_vector_uchar_basis_c_type; 
typedef char                                gsl_vector_char_basis_c_type; 

typedef long double                         gsl_vector_complex_long_double_view_basis_c_type; 
typedef double                              gsl_vector_complex_double_view_basis_c_type; 
typedef float                               gsl_vector_complex_float_view_basis_c_type; 
typedef double                              gsl_vector_complex_view_basis_c_type; 
typedef long double                         gsl_vector_long_double_view_basis_c_type; 
typedef double                              gsl_vector_double_view_basis_c_type; 
typedef float                               gsl_vector_float_view_basis_c_type; 
typedef double                              gsl_vector_view_basis_c_type; 
typedef unsigned long                       gsl_vector_ulong_view_basis_c_type; 
typedef long                                gsl_vector_long_view_basis_c_type; 
typedef unsigned int                        gsl_vector_uint_view_basis_c_type; 
typedef int                                 gsl_vector_int_view_basis_c_type; 
typedef unsigned short                      gsl_vector_ushort_view_basis_c_type; 
typedef short                               gsl_vector_short_view_basis_c_type; 
typedef unsigned char                       gsl_vector_uchar_view_basis_c_type; 
typedef char                                gsl_vector_char_view_basis_c_type; 


#define GET_gsl_vector_complex_long_double             gsl_vector_complex_long_double_get
#define GET_gsl_vector_complex_double                  gsl_vector_complex_double_get
#define GET_gsl_vector_complex_float                   gsl_vector_complex_float_get
#define GET_gsl_vector_complex                         gsl_vector_complex_get
#define GET_gsl_vector_long_double                     gsl_vector_long_double_get
#define GET_gsl_vector_double                          gsl_vector_double_get
#define GET_gsl_vector_float                           gsl_vector_float_get
#define GET_gsl_vector                                 gsl_vector_get
#define GET_gsl_vector_ulong                           gsl_vector_ulong_get
#define GET_gsl_vector_long                            gsl_vector_long_get
#define GET_gsl_vector_uint                            gsl_vector_uint_get
#define GET_gsl_vector_int                             gsl_vector_int_get
#define GET_gsl_vector_ushort                          gsl_vector_ushort_get
#define GET_gsl_vector_short                           gsl_vector_short_get
#define GET_gsl_vector_uchar                           gsl_vector_uchar_get
#define GET_gsl_vector_char                            gsl_vector_char_get

#define GET_gsl_vector_complex_long_double_view        gsl_vector_complex_long_double_get
#define GET_gsl_vector_complex_double_view             gsl_vector_complex_double_get
#define GET_gsl_vector_complex_float_view              gsl_vector_complex_float_get
#define GET_gsl_vector_complex_view                    gsl_vector_complex_get
#define GET_gsl_vector_long_double_view                gsl_vector_long_double_get
#define GET_gsl_vector_double_view                     gsl_vector_double_get
#define GET_gsl_vector_float_view                      gsl_vector_float_get
#define GET_gsl_vector_view                            gsl_vector_get
#define GET_gsl_vector_ulong_view                      gsl_vector_ulong_get
#define GET_gsl_vector_long_view                       gsl_vector_long_get
#define GET_gsl_vector_uint_view                       gsl_vector_uint_get
#define GET_gsl_vector_int_view                        gsl_vector_int_get
#define GET_gsl_vector_ushort_view                     gsl_vector_ushort_get
#define GET_gsl_vector_short_view                      gsl_vector_short_get
#define GET_gsl_vector_uchar_view                      gsl_vector_uchar_get
#define GET_gsl_vector_char_view                       gsl_vector_char_get


enum {
gsl_vector_complex_long_double_py_array_type       = PyArray_NOTYPE  ,
gsl_vector_complex_double_py_array_type            = PyArray_CDOUBLE ,
gsl_vector_complex_float_py_array_type             = PyArray_CFLOAT  ,
gsl_vector_complex_py_array_type                   = PyArray_CDOUBLE ,
gsl_vector_long_double_py_array_type               = PyArray_NOTYPE  ,
gsl_vector_double_py_array_type                    = PyArray_DOUBLE  ,
gsl_vector_float_py_array_type                     = PyArray_FLOAT   ,
gsl_vector_py_array_type                           = PyArray_DOUBLE  ,
gsl_vector_ulong_py_array_type                     = PyArray_NOTYPE  ,
gsl_vector_long_py_array_type                      = PyArray_LONG    ,
gsl_vector_uint_py_array_type                      = PyArray_NOTYPE  ,
gsl_vector_int_py_array_type                       = PyArray_INT     ,
gsl_vector_ushort_py_array_type                    = PyArray_NOTYPE  ,
gsl_vector_short_py_array_type                     = PyArray_SHORT   ,
gsl_vector_uchar_py_array_type                     = PyArray_NOTYPE  ,
gsl_vector_char_py_array_type                      = PyArray_CHAR    ,

gsl_vector_complex_long_double_view_py_array_type  = PyArray_NOTYPE  ,
gsl_vector_complex_double_view_py_array_type       = PyArray_CDOUBLE ,
gsl_vector_complex_float_view_py_array_type        = PyArray_CFLOAT  ,
gsl_vector_complex_view_py_array_type              = PyArray_CDOUBLE ,
gsl_vector_long_double_view_py_array_type          = PyArray_NOTYPE  ,
gsl_vector_double_view_py_array_type               = PyArray_DOUBLE  ,
gsl_vector_float_view_py_array_type                = PyArray_FLOAT   ,
gsl_vector_view_py_array_type                      = PyArray_DOUBLE  ,
gsl_vector_ulong_view_py_array_type                = PyArray_NOTYPE  ,
gsl_vector_long_view_py_array_type                 = PyArray_LONG    ,
gsl_vector_uint_view_py_array_type                 = PyArray_NOTYPE  ,
gsl_vector_int_view_py_array_type                  = PyArray_INT     ,
gsl_vector_ushort_view_py_array_type               = PyArray_NOTYPE  ,
gsl_vector_short_view_py_array_type                = PyArray_SHORT   ,
gsl_vector_uchar_view_py_array_type                = PyArray_NOTYPE  ,
gsl_vector_char_view_py_array_type                 = PyArray_CHAR    ,

};

#define TYPE_VIEW_gsl_vector_complex_long_double              gsl_vector_complex_long_double_view
#define TYPE_VIEW_gsl_vector_complex_double                   gsl_vector_complex_double_view
#define TYPE_VIEW_gsl_vector_complex_float                    gsl_vector_complex_float_view
#define TYPE_VIEW_gsl_vector_complex                          gsl_vector_complex_view
#define TYPE_VIEW_gsl_vector_long_double                      gsl_vector_long_double_view
#define TYPE_VIEW_gsl_vector_double                           gsl_vector_double_view
#define TYPE_VIEW_gsl_vector_float                            gsl_vector_float_view
#define TYPE_VIEW_gsl_vector                                  gsl_vector_view
#define TYPE_VIEW_gsl_vector_ulong                            gsl_vector_ulong_view
#define TYPE_VIEW_gsl_vector_long                             gsl_vector_long_view
#define TYPE_VIEW_gsl_vector_uint                             gsl_vector_uint_view
#define TYPE_VIEW_gsl_vector_int                              gsl_vector_int_view
#define TYPE_VIEW_gsl_vector_ushort                           gsl_vector_ushort_view
#define TYPE_VIEW_gsl_vector_short                            gsl_vector_short_view
#define TYPE_VIEW_gsl_vector_uchar                            gsl_vector_uchar_view
#define TYPE_VIEW_gsl_vector_char                             gsl_vector_char_view

#define TYPE_VIEW_gsl_vector_complex_long_double_view         gsl_vector_complex_long_double_view_view
#define TYPE_VIEW_gsl_vector_complex_double_view              gsl_vector_complex_double_view_view
#define TYPE_VIEW_gsl_vector_complex_float_view               gsl_vector_complex_float_view_view
#define TYPE_VIEW_gsl_vector_complex_view                     gsl_vector_complex_view_view
#define TYPE_VIEW_gsl_vector_long_double_view                 gsl_vector_long_double_view_view
#define TYPE_VIEW_gsl_vector_double_view                      gsl_vector_double_view_view
#define TYPE_VIEW_gsl_vector_float_view                       gsl_vector_float_view_view
#define TYPE_VIEW_gsl_vector_view                             gsl_vector_view_view
#define TYPE_VIEW_gsl_vector_ulong_view                       gsl_vector_ulong_view_view
#define TYPE_VIEW_gsl_vector_long_view                        gsl_vector_long_view_view
#define TYPE_VIEW_gsl_vector_uint_view                        gsl_vector_uint_view_view
#define TYPE_VIEW_gsl_vector_int_view                         gsl_vector_int_view_view
#define TYPE_VIEW_gsl_vector_ushort_view                      gsl_vector_ushort_view_view
#define TYPE_VIEW_gsl_vector_short_view                       gsl_vector_short_view_view
#define TYPE_VIEW_gsl_vector_uchar_view                       gsl_vector_uchar_view_view
#define TYPE_VIEW_gsl_vector_char_view                        gsl_vector_char_view_view


#define TYPE_VIEW_ARRAY_gsl_vector_complex_long_double              gsl_vector_complex_long_double_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_complex_double                   gsl_vector_complex_double_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_complex_float                    gsl_vector_complex_float_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_complex                          gsl_vector_complex_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_long_double                      gsl_vector_long_double_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_double                           gsl_vector_double_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_float                            gsl_vector_float_view_array
#define TYPE_VIEW_ARRAY_gsl_vector                                  gsl_vector_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_ulong                            gsl_vector_ulong_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_long                             gsl_vector_long_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_uint                             gsl_vector_uint_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_int                              gsl_vector_int_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_ushort                           gsl_vector_ushort_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_short                            gsl_vector_short_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_uchar                            gsl_vector_uchar_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_char                             gsl_vector_char_view_array

#define TYPE_VIEW_ARRAY_gsl_vector_complex_long_double_view         gsl_vector_complex_long_double_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_complex_double_view              gsl_vector_complex_double_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_complex_float_view               gsl_vector_complex_float_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_complex_view                     gsl_vector_complex_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_long_double_view                 gsl_vector_long_double_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_double_view                      gsl_vector_double_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_float_view                       gsl_vector_float_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_view                             gsl_vector_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_ulong_view                       gsl_vector_ulong_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_long_view                        gsl_vector_long_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_uint_view                        gsl_vector_uint_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_int_view                         gsl_vector_int_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_ushort_view                      gsl_vector_ushort_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_short_view                       gsl_vector_short_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_uchar_view                       gsl_vector_uchar_view_array
#define TYPE_VIEW_ARRAY_gsl_vector_char_view                        gsl_vector_char_view_array


#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_complex_long_double              gsl_vector_complex_long_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_complex_double                   gsl_vector_complex_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_complex_float                    gsl_vector_complex_float_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_complex                          gsl_vector_complex_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_long_double                      gsl_vector_long_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_double                           gsl_vector_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_float                            gsl_vector_float_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector                                  gsl_vector_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_ulong                            gsl_vector_ulong_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_long                             gsl_vector_long_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_uint                             gsl_vector_uint_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_int                              gsl_vector_int_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_ushort                           gsl_vector_ushort_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_short                            gsl_vector_short_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_uchar                            gsl_vector_uchar_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_char                             gsl_vector_char_view_array_with_stride

#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_complex_long_double_view         gsl_vector_complex_long_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_complex_double_view              gsl_vector_complex_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_complex_float_view               gsl_vector_complex_float_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_complex_view                     gsl_vector_complex_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_long_double_view                 gsl_vector_long_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_double_view                      gsl_vector_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_float_view                       gsl_vector_float_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_view                             gsl_vector_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_ulong_view                       gsl_vector_ulong_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_long_view                        gsl_vector_long_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_uint_view                        gsl_vector_uint_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_int_view                         gsl_vector_int_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_ushort_view                      gsl_vector_ushort_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_short_view                       gsl_vector_short_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_uchar_view                       gsl_vector_uchar_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_vector_char_view                        gsl_vector_char_view_array_with_stride



#define BASIS_gsl_matrix_complex_long_double             gsl_matrix_complex_long_double
#define BASIS_gsl_matrix_complex_double                  gsl_matrix_complex_double
#define BASIS_gsl_matrix_complex_float                   gsl_matrix_complex_float
#define BASIS_gsl_matrix_complex                         gsl_matrix_complex
#define BASIS_gsl_matrix_long_double                     gsl_matrix_long_double
#define BASIS_gsl_matrix_double                          gsl_matrix_double
#define BASIS_gsl_matrix_float                           gsl_matrix_float
#define BASIS_gsl_matrix                                 gsl_matrix
#define BASIS_gsl_matrix_ulong                           gsl_matrix_ulong
#define BASIS_gsl_matrix_long                            gsl_matrix_long
#define BASIS_gsl_matrix_uint                            gsl_matrix_uint
#define BASIS_gsl_matrix_int                             gsl_matrix_int
#define BASIS_gsl_matrix_ushort                          gsl_matrix_ushort
#define BASIS_gsl_matrix_short                           gsl_matrix_short
#define BASIS_gsl_matrix_uchar                           gsl_matrix_uchar
#define BASIS_gsl_matrix_char                            gsl_matrix_char

#define BASIS_gsl_matrix_complex_long_double_view        gsl_matrix_complex_long_double
#define BASIS_gsl_matrix_complex_double_view             gsl_matrix_complex_double
#define BASIS_gsl_matrix_complex_float_view              gsl_matrix_complex_float
#define BASIS_gsl_matrix_complex_view                    gsl_matrix_complex
#define BASIS_gsl_matrix_long_double_view                gsl_matrix_long_double
#define BASIS_gsl_matrix_double_view                     gsl_matrix_double
#define BASIS_gsl_matrix_float_view                      gsl_matrix_float
#define BASIS_gsl_matrix_view                            gsl_matrix
#define BASIS_gsl_matrix_ulong_view                      gsl_matrix_ulong
#define BASIS_gsl_matrix_long_view                       gsl_matrix_long
#define BASIS_gsl_matrix_uint_view                       gsl_matrix_uint
#define BASIS_gsl_matrix_int_view                        gsl_matrix_int
#define BASIS_gsl_matrix_ushort_view                     gsl_matrix_ushort
#define BASIS_gsl_matrix_short_view                      gsl_matrix_short
#define BASIS_gsl_matrix_uchar_view                      gsl_matrix_uchar
#define BASIS_gsl_matrix_char_view                       gsl_matrix_char


typedef gsl_complex_long_double             gsl_matrix_complex_long_double_basis_type; 
typedef gsl_complex                         gsl_matrix_complex_double_basis_type; 
typedef gsl_complex_float                   gsl_matrix_complex_float_basis_type; 
typedef gsl_complex                         gsl_matrix_complex_basis_type; 
typedef long double                         gsl_matrix_long_double_basis_type; 
typedef double                              gsl_matrix_double_basis_type; 
typedef float                               gsl_matrix_float_basis_type; 
typedef double                              gsl_matrix_basis_type; 
typedef unsigned long                       gsl_matrix_ulong_basis_type; 
typedef long                                gsl_matrix_long_basis_type; 
typedef unsigned int                        gsl_matrix_uint_basis_type; 
typedef int                                 gsl_matrix_int_basis_type; 
typedef unsigned short                      gsl_matrix_ushort_basis_type; 
typedef short                               gsl_matrix_short_basis_type; 
typedef unsigned char                       gsl_matrix_uchar_basis_type; 
typedef char                                gsl_matrix_char_basis_type; 

typedef gsl_complex_long_double             gsl_matrix_complex_long_double_view_basis_type; 
typedef gsl_complex                         gsl_matrix_complex_double_view_basis_type; 
typedef gsl_complex_float                   gsl_matrix_complex_float_view_basis_type; 
typedef gsl_complex                         gsl_matrix_complex_view_basis_type; 
typedef long double                         gsl_matrix_long_double_view_basis_type; 
typedef double                              gsl_matrix_double_view_basis_type; 
typedef float                               gsl_matrix_float_view_basis_type; 
typedef double                              gsl_matrix_view_basis_type; 
typedef unsigned long                       gsl_matrix_ulong_view_basis_type; 
typedef long                                gsl_matrix_long_view_basis_type; 
typedef unsigned int                        gsl_matrix_uint_view_basis_type; 
typedef int                                 gsl_matrix_int_view_basis_type; 
typedef unsigned short                      gsl_matrix_ushort_view_basis_type; 
typedef short                               gsl_matrix_short_view_basis_type; 
typedef unsigned char                       gsl_matrix_uchar_view_basis_type; 
typedef char                                gsl_matrix_char_view_basis_type; 


typedef long double                         gsl_matrix_complex_long_double_basis_c_type; 
typedef double                              gsl_matrix_complex_double_basis_c_type; 
typedef float                               gsl_matrix_complex_float_basis_c_type; 
typedef double                              gsl_matrix_complex_basis_c_type; 
typedef long double                         gsl_matrix_long_double_basis_c_type; 
typedef double                              gsl_matrix_double_basis_c_type; 
typedef float                               gsl_matrix_float_basis_c_type; 
typedef double                              gsl_matrix_basis_c_type; 
typedef unsigned long                       gsl_matrix_ulong_basis_c_type; 
typedef long                                gsl_matrix_long_basis_c_type; 
typedef unsigned int                        gsl_matrix_uint_basis_c_type; 
typedef int                                 gsl_matrix_int_basis_c_type; 
typedef unsigned short                      gsl_matrix_ushort_basis_c_type; 
typedef short                               gsl_matrix_short_basis_c_type; 
typedef unsigned char                       gsl_matrix_uchar_basis_c_type; 
typedef char                                gsl_matrix_char_basis_c_type; 

typedef long double                         gsl_matrix_complex_long_double_view_basis_c_type; 
typedef double                              gsl_matrix_complex_double_view_basis_c_type; 
typedef float                               gsl_matrix_complex_float_view_basis_c_type; 
typedef double                              gsl_matrix_complex_view_basis_c_type; 
typedef long double                         gsl_matrix_long_double_view_basis_c_type; 
typedef double                              gsl_matrix_double_view_basis_c_type; 
typedef float                               gsl_matrix_float_view_basis_c_type; 
typedef double                              gsl_matrix_view_basis_c_type; 
typedef unsigned long                       gsl_matrix_ulong_view_basis_c_type; 
typedef long                                gsl_matrix_long_view_basis_c_type; 
typedef unsigned int                        gsl_matrix_uint_view_basis_c_type; 
typedef int                                 gsl_matrix_int_view_basis_c_type; 
typedef unsigned short                      gsl_matrix_ushort_view_basis_c_type; 
typedef short                               gsl_matrix_short_view_basis_c_type; 
typedef unsigned char                       gsl_matrix_uchar_view_basis_c_type; 
typedef char                                gsl_matrix_char_view_basis_c_type; 


#define GET_gsl_matrix_complex_long_double             gsl_matrix_complex_long_double_get
#define GET_gsl_matrix_complex_double                  gsl_matrix_complex_double_get
#define GET_gsl_matrix_complex_float                   gsl_matrix_complex_float_get
#define GET_gsl_matrix_complex                         gsl_matrix_complex_get
#define GET_gsl_matrix_long_double                     gsl_matrix_long_double_get
#define GET_gsl_matrix_double                          gsl_matrix_double_get
#define GET_gsl_matrix_float                           gsl_matrix_float_get
#define GET_gsl_matrix                                 gsl_matrix_get
#define GET_gsl_matrix_ulong                           gsl_matrix_ulong_get
#define GET_gsl_matrix_long                            gsl_matrix_long_get
#define GET_gsl_matrix_uint                            gsl_matrix_uint_get
#define GET_gsl_matrix_int                             gsl_matrix_int_get
#define GET_gsl_matrix_ushort                          gsl_matrix_ushort_get
#define GET_gsl_matrix_short                           gsl_matrix_short_get
#define GET_gsl_matrix_uchar                           gsl_matrix_uchar_get
#define GET_gsl_matrix_char                            gsl_matrix_char_get

#define GET_gsl_matrix_complex_long_double_view        gsl_matrix_complex_long_double_get
#define GET_gsl_matrix_complex_double_view             gsl_matrix_complex_double_get
#define GET_gsl_matrix_complex_float_view              gsl_matrix_complex_float_get
#define GET_gsl_matrix_complex_view                    gsl_matrix_complex_get
#define GET_gsl_matrix_long_double_view                gsl_matrix_long_double_get
#define GET_gsl_matrix_double_view                     gsl_matrix_double_get
#define GET_gsl_matrix_float_view                      gsl_matrix_float_get
#define GET_gsl_matrix_view                            gsl_matrix_get
#define GET_gsl_matrix_ulong_view                      gsl_matrix_ulong_get
#define GET_gsl_matrix_long_view                       gsl_matrix_long_get
#define GET_gsl_matrix_uint_view                       gsl_matrix_uint_get
#define GET_gsl_matrix_int_view                        gsl_matrix_int_get
#define GET_gsl_matrix_ushort_view                     gsl_matrix_ushort_get
#define GET_gsl_matrix_short_view                      gsl_matrix_short_get
#define GET_gsl_matrix_uchar_view                      gsl_matrix_uchar_get
#define GET_gsl_matrix_char_view                       gsl_matrix_char_get


enum {
gsl_matrix_complex_long_double_py_array_type       = PyArray_NOTYPE  ,
gsl_matrix_complex_double_py_array_type            = PyArray_CDOUBLE ,
gsl_matrix_complex_float_py_array_type             = PyArray_CFLOAT  ,
gsl_matrix_complex_py_array_type                   = PyArray_CDOUBLE ,
gsl_matrix_long_double_py_array_type               = PyArray_NOTYPE  ,
gsl_matrix_double_py_array_type                    = PyArray_DOUBLE  ,
gsl_matrix_float_py_array_type                     = PyArray_FLOAT   ,
gsl_matrix_py_array_type                           = PyArray_DOUBLE  ,
gsl_matrix_ulong_py_array_type                     = PyArray_NOTYPE  ,
gsl_matrix_long_py_array_type                      = PyArray_LONG    ,
gsl_matrix_uint_py_array_type                      = PyArray_NOTYPE  ,
gsl_matrix_int_py_array_type                       = PyArray_INT     ,
gsl_matrix_ushort_py_array_type                    = PyArray_NOTYPE  ,
gsl_matrix_short_py_array_type                     = PyArray_SHORT   ,
gsl_matrix_uchar_py_array_type                     = PyArray_NOTYPE  ,
gsl_matrix_char_py_array_type                      = PyArray_CHAR    ,

gsl_matrix_complex_long_double_view_py_array_type  = PyArray_NOTYPE  ,
gsl_matrix_complex_double_view_py_array_type       = PyArray_CDOUBLE ,
gsl_matrix_complex_float_view_py_array_type        = PyArray_CFLOAT  ,
gsl_matrix_complex_view_py_array_type              = PyArray_CDOUBLE ,
gsl_matrix_long_double_view_py_array_type          = PyArray_NOTYPE  ,
gsl_matrix_double_view_py_array_type               = PyArray_DOUBLE  ,
gsl_matrix_float_view_py_array_type                = PyArray_FLOAT   ,
gsl_matrix_view_py_array_type                      = PyArray_DOUBLE  ,
gsl_matrix_ulong_view_py_array_type                = PyArray_NOTYPE  ,
gsl_matrix_long_view_py_array_type                 = PyArray_LONG    ,
gsl_matrix_uint_view_py_array_type                 = PyArray_NOTYPE  ,
gsl_matrix_int_view_py_array_type                  = PyArray_INT     ,
gsl_matrix_ushort_view_py_array_type               = PyArray_NOTYPE  ,
gsl_matrix_short_view_py_array_type                = PyArray_SHORT   ,
gsl_matrix_uchar_view_py_array_type                = PyArray_NOTYPE  ,
gsl_matrix_char_view_py_array_type                 = PyArray_CHAR    ,

};

#define TYPE_VIEW_gsl_matrix_complex_long_double              gsl_matrix_complex_long_double_view
#define TYPE_VIEW_gsl_matrix_complex_double                   gsl_matrix_complex_double_view
#define TYPE_VIEW_gsl_matrix_complex_float                    gsl_matrix_complex_float_view
#define TYPE_VIEW_gsl_matrix_complex                          gsl_matrix_complex_view
#define TYPE_VIEW_gsl_matrix_long_double                      gsl_matrix_long_double_view
#define TYPE_VIEW_gsl_matrix_double                           gsl_matrix_double_view
#define TYPE_VIEW_gsl_matrix_float                            gsl_matrix_float_view
#define TYPE_VIEW_gsl_matrix                                  gsl_matrix_view
#define TYPE_VIEW_gsl_matrix_ulong                            gsl_matrix_ulong_view
#define TYPE_VIEW_gsl_matrix_long                             gsl_matrix_long_view
#define TYPE_VIEW_gsl_matrix_uint                             gsl_matrix_uint_view
#define TYPE_VIEW_gsl_matrix_int                              gsl_matrix_int_view
#define TYPE_VIEW_gsl_matrix_ushort                           gsl_matrix_ushort_view
#define TYPE_VIEW_gsl_matrix_short                            gsl_matrix_short_view
#define TYPE_VIEW_gsl_matrix_uchar                            gsl_matrix_uchar_view
#define TYPE_VIEW_gsl_matrix_char                             gsl_matrix_char_view

#define TYPE_VIEW_gsl_matrix_complex_long_double_view         gsl_matrix_complex_long_double_view_view
#define TYPE_VIEW_gsl_matrix_complex_double_view              gsl_matrix_complex_double_view_view
#define TYPE_VIEW_gsl_matrix_complex_float_view               gsl_matrix_complex_float_view_view
#define TYPE_VIEW_gsl_matrix_complex_view                     gsl_matrix_complex_view_view
#define TYPE_VIEW_gsl_matrix_long_double_view                 gsl_matrix_long_double_view_view
#define TYPE_VIEW_gsl_matrix_double_view                      gsl_matrix_double_view_view
#define TYPE_VIEW_gsl_matrix_float_view                       gsl_matrix_float_view_view
#define TYPE_VIEW_gsl_matrix_view                             gsl_matrix_view_view
#define TYPE_VIEW_gsl_matrix_ulong_view                       gsl_matrix_ulong_view_view
#define TYPE_VIEW_gsl_matrix_long_view                        gsl_matrix_long_view_view
#define TYPE_VIEW_gsl_matrix_uint_view                        gsl_matrix_uint_view_view
#define TYPE_VIEW_gsl_matrix_int_view                         gsl_matrix_int_view_view
#define TYPE_VIEW_gsl_matrix_ushort_view                      gsl_matrix_ushort_view_view
#define TYPE_VIEW_gsl_matrix_short_view                       gsl_matrix_short_view_view
#define TYPE_VIEW_gsl_matrix_uchar_view                       gsl_matrix_uchar_view_view
#define TYPE_VIEW_gsl_matrix_char_view                        gsl_matrix_char_view_view


#define TYPE_VIEW_ARRAY_gsl_matrix_complex_long_double              gsl_matrix_complex_long_double_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_complex_double                   gsl_matrix_complex_double_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_complex_float                    gsl_matrix_complex_float_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_complex                          gsl_matrix_complex_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_long_double                      gsl_matrix_long_double_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_double                           gsl_matrix_double_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_float                            gsl_matrix_float_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix                                  gsl_matrix_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_ulong                            gsl_matrix_ulong_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_long                             gsl_matrix_long_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_uint                             gsl_matrix_uint_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_int                              gsl_matrix_int_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_ushort                           gsl_matrix_ushort_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_short                            gsl_matrix_short_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_uchar                            gsl_matrix_uchar_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_char                             gsl_matrix_char_view_array

#define TYPE_VIEW_ARRAY_gsl_matrix_complex_long_double_view         gsl_matrix_complex_long_double_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_complex_double_view              gsl_matrix_complex_double_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_complex_float_view               gsl_matrix_complex_float_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_complex_view                     gsl_matrix_complex_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_long_double_view                 gsl_matrix_long_double_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_double_view                      gsl_matrix_double_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_float_view                       gsl_matrix_float_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_view                             gsl_matrix_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_ulong_view                       gsl_matrix_ulong_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_long_view                        gsl_matrix_long_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_uint_view                        gsl_matrix_uint_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_int_view                         gsl_matrix_int_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_ushort_view                      gsl_matrix_ushort_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_short_view                       gsl_matrix_short_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_uchar_view                       gsl_matrix_uchar_view_array
#define TYPE_VIEW_ARRAY_gsl_matrix_char_view                        gsl_matrix_char_view_array


#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_complex_long_double              gsl_matrix_complex_long_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_complex_double                   gsl_matrix_complex_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_complex_float                    gsl_matrix_complex_float_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_complex                          gsl_matrix_complex_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_long_double                      gsl_matrix_long_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_double                           gsl_matrix_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_float                            gsl_matrix_float_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix                                  gsl_matrix_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_ulong                            gsl_matrix_ulong_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_long                             gsl_matrix_long_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_uint                             gsl_matrix_uint_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_int                              gsl_matrix_int_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_ushort                           gsl_matrix_ushort_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_short                            gsl_matrix_short_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_uchar                            gsl_matrix_uchar_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_char                             gsl_matrix_char_view_array_with_stride

#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_complex_long_double_view         gsl_matrix_complex_long_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_complex_double_view              gsl_matrix_complex_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_complex_float_view               gsl_matrix_complex_float_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_complex_view                     gsl_matrix_complex_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_long_double_view                 gsl_matrix_long_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_double_view                      gsl_matrix_double_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_float_view                       gsl_matrix_float_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_view                             gsl_matrix_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_ulong_view                       gsl_matrix_ulong_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_long_view                        gsl_matrix_long_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_uint_view                        gsl_matrix_uint_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_int_view                         gsl_matrix_int_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_ushort_view                      gsl_matrix_ushort_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_short_view                       gsl_matrix_short_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_uchar_view                       gsl_matrix_uchar_view_array_with_stride
#define TYPE_VIEW_ARRAY_STRIDES_gsl_matrix_char_view                        gsl_matrix_char_view_array_with_stride




/* EOF */
        
