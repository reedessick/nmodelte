# Just for declaration
__all__ = ["gsl_Extension"]
