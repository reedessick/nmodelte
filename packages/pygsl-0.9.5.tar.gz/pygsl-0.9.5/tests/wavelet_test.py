#!/usr/bin/env python
import unittest
import pygsl.wavelet as wavelet

