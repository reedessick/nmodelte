/* gsl_function */
char * pygsl_gsl_function = "gsl_function";
char * pygsl_gsl_f_function = "gsl_function_f";
char * pygsl_gsl_df_function = "gsl_function_df";
char * pygsl_gsl_fdf_function = "gsl_function_fdf";
/* gsl_multifit */
char * pygsl_multifit_function     = "multifit_function";
char * pygsl_multifit_f_function   = "multifit_f";
char * pygsl_multifit_df_function  = "multifit_df";
char * pygsl_multifit_fdf_function = "multifit_fdf";

char * pygsl_multimin_function     = "multimin_function";
char * pygsl_multimin_f_function   = "multimin_f";
char * pygsl_multimin_df_function  = "multimin_df";
char * pygsl_multimin_fdf_function = "multimin_fdf";
/* gsl_multiroot */
char * pygsl_multiroot_function     = "multiroot_function";
char * pygsl_multiroot_f_function   = "multiroot_f";
char * pygsl_multiroot_df_function  = "multiroot_df";
char * pygsl_multiroot_fdf_function = "multiroot_fdf";

char * pygsl_monte_function = "monte_function";
