weave provides tools for including C/C++ code within Python.

For instructions on installation, see the tutorial file located in 
doc/tutorial.html or weave/doc/tutorial.html, depending upon how weave was 
packaged.

The LICENSE.txt file (either in this directory or in the weave directory) has 
licenses for all the code distributed in this package.  All licenses allow free 
use of the package for both commercial and non-commercial
purposes.