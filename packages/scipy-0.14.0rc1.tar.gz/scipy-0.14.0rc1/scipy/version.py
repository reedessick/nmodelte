
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.14.0rc1'
version = '0.14.0rc1'
full_version = '0.14.0rc1'
git_revision = '79ceef7d5d319abdf14360e3a08dc57f48d6aa7f'
release = True

if not release:
    version = full_version
